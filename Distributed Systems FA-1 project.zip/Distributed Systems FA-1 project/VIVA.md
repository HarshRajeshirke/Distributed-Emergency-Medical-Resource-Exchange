# Distributed Systems FA-1 Viva Preparation Guide

**Project:** Distributed Emergency Medical Resource Exchange  
**Target:** 20+ High-Yield Viva Questions & Answers for FA-1 Demonstration  

---

### Q1: What is a Distributed System?
**Ans:** A distributed system is a collection of autonomous, independent computers/processes connected over a network that coordinate actions by passing messages and appear to end-users as a single coherent system.

---

### Q2: Why is this project classified as a Distributed System?
**Ans:** Because each hospital and blood bank node runs as an independent process with its own dedicated network port and its own isolated local SQLite database. There is no central hospital database controlling everything; all resource sharing happens via network protocols (RPC, P2P sockets, and Message Broker).

---

### Q3: Why not use a single centralized database and server?
**Ans:** A centralized database creates:
1. **Single Point of Failure (SPOF):** If the central server crashes, all hospitals lose access.
2. **Performance Bottleneck:** High traffic from all hospitals congests the central server.
3. **Lack of Autonomy:** Hospitals are independent administrative entities and must maintain sovereign control over their own local inventory and patient records.

---

### Q4: What is Middleware, and where is it in your project?
**Ans:** Middleware is software that sits between high-level application logic and the underlying OS/network sockets, hiding communication and data serialization complexity. In our project, the XML-RPC server/client, Pub/Sub message broker, WebSocket stream server, and P2P sockets form the middleware layer.

---

### Q5: What is RPC (Remote Procedure Call)?
**Ans:** RPC allows a client program to execute a function/procedure on a remote server across a network as if it were a local function call, without having to manually code socket connections and byte marshaling.

---

### Q6: Why did you choose Python XML-RPC?
**Ans:** Python XML-RPC is part of the standard library (`xmlrpc.server` & `xmlrpc.client`), requires zero external heavy dependencies, is platform-independent, and cleanly demonstrates procedure call abstraction using standard XML/HTTP formatting.

---

### Q7: What RPC functions did you implement?
**Ans:** We implemented three core RPC procedures:
1. `checkResourceAvailability(resource_type)` – queries if a remote node has available stock.
2. `requestResource(requester_id, resource_type, quantity)` – reserves and deducts resources from the remote node's local database.
3. `getNodeStatus()` – retrieves live operational status and inventory catalog of a node.

---

### Q8: What is Message-Oriented Communication (Pub/Sub)?
**Ans:** Message-oriented communication is asynchronous and decoupled. Senders (publishers) publish messages to topics on a message broker without knowing who the receivers (subscribers) are, and subscribers receive messages without waiting synchronously.

---

### Q9: Give an example of Message-Oriented Communication from your demo.
**Ans:** When Hospital A needs rare blood, it publishes: *"URGENT: O-negative blood required"* to the topic `EMERGENCY_BROADCAST`. The message broker asynchronously delivers this alert to all subscribed facilities (Central Blood Bank and Hospital C) simultaneously.

---

### Q10: What is Stream-Oriented Communication?
**Ans:** Stream-oriented communication transmits a continuous, time-dependent sequence of data packets over a persistent connection where timing and periodic delivery matter (e.g. WebSocket or audio/video streams).

---

### Q11: How is Stream-Oriented Communication implemented in your project?
**Ans:** A WebSocket server (`ws://127.0.0.1:8765`) gathers real-time resource telemetry across all nodes and streams live JSON updates every 2.5 seconds to connected dashboard clients to reflect real-time hospital bed and oxygen levels.

---

### Q12: What is P2P (Peer-to-Peer) Communication, and how does it differ from Client-Server?
**Ans:** In P2P, every node acts as both a client and a server (servent). Nodes communicate directly with each other over raw TCP sockets without routing messages through any central server or broker.

---

### Q13: How did you implement P2P in this project?
**Ans:** Each hospital node runs a dedicated TCP socket listener on ports 9001–9005. Hospital A connects directly to Hospital C on port 9003, sends a direct JSON allocation request for a Ventilator, receives a direct confirmation, and sends an ACK frame back—completely bypassing the message broker.

---

### Q14: What is WebRTC, and what role does it play in Distributed Multimedia?
**Ans:** WebRTC (Web Real-Time Communication) enables direct peer-to-peer browser communication for audio, video, and arbitrary data channels (`RTCDataChannel`) without routing traffic through an application server. It demonstrates Distributed Multimedia Systems in Unit 1.

---

### Q15: What is the role of the Signaling Server in WebRTC?
**Ans:** WebRTC peers cannot find each other automatically. The Signaling Server (running on WebSocket port 8766) acts as a temporary discovery intermediary to exchange SDP (Session Description Protocol) offers, answers, and ICE network candidates. Once the connection is established, all communication happens directly peer-to-peer over `RTCDataChannel`.

---

### Q16: What is Naming, Identifying, and Addressing in Distributed Systems?
**Ans:** 
- **Name:** Human-friendly label (e.g., `Hospital A (General Hospital)`).
- **Identifier:** Unique, immutable identifier (e.g., `HOSP-MUM-001`).
- **Address:** The physical network endpoint used to reach the entity (e.g., `127.0.0.1:8001`).

---

### Q17: What is Fault Tolerance in Distributed Systems?
**Ans:** Fault tolerance is the capability of a distributed system to continue operating properly in the event of the failure of one or more of its components (nodes, networks, or processes).

---

### Q18: What happens during your Fault Tolerance demonstration?
**Ans:** 
1. Hospital A sends an RPC request to Hospital B for an ICU bed.
2. Hospital B is offline / crashed.
3. Hospital A detects a **Socket Timeout**.
4. Hospital A executes **Retry 1** and **Retry 2**.
5. When Hospital B remains unreachable, Hospital A triggers automated **Failover** to the backup node (Hospital C).
6. Hospital C receives the request and confirms the ICU bed allocation.

---

### Q19: What is the difference between Synchronous and Asynchronous Communication?
**Ans:** 
- **Synchronous:** The sender blocks and waits until the receiver processes the message and returns a reply (e.g., XML-RPC and direct P2P TCP socket calls).
- **Asynchronous:** The sender transmits the message and immediately resumes other tasks without waiting for immediate delivery or response (e.g., Pub/Sub Message Broker broadcasts).

---

### Q20: What is the Model of Distributed Computation?
**Ans:** It models execution as a sequence of **Local Events** (internal computations, such as querying a local SQLite database) and **Communication Events** (message send and receive operations over network sockets).

---

### Q21: How does Virtualization apply to this project?
**Ans:** In this FA-1 prototype, multiple independent hospital node processes run concurrently on a single machine, simulating separate physical servers with dedicated ports and local storage. In production, each process maps directly into an isolated Docker container or Virtual Machine (VM).

---

### Q22: What Transparency types are demonstrated in this project?
**Ans:**
1. **Access Transparency:** Identical method calls are used regardless of whether the target is local or remote.
2. **Location Transparency:** Callers address target nodes using logical identifiers rather than raw memory pointers.
3. **Failure Transparency:** The client automatically masks server crashes by failing over to backup nodes.

---

### Q23: What are the main Design Issues in Distributed Systems and how are they addressed?
**Ans:**
- **Heterogeneity:** Addressed via open standards (JSON, XML-RPC, WebSockets).
- **Scalability:** Addressed via decentralized local databases and topic-based message routing.
- **Failure Handling:** Addressed via timeouts, retries, and automated failover.
- **Concurrency:** Addressed via multi-threaded RPC servers and thread-safe database connection locks.

---

### Q24: Walk through the complete emergency workflow scenario.
**Ans:**
1. **Emergency Admission:** Hospital A receives a trauma patient and needs an ICU bed.
2. **RPC Query:** Hospital A queries Hospital B via XML-RPC and reserves Bed #3.
3. **Urgent Blood Shortage:** Hospital A discovers low O- Blood reserves and publishes an asynchronous broadcast to the Pub/Sub broker.
4. **Broadcast Reception:** Central Blood Bank and Hospital C receive the alert and prepare blood units.
5. **Direct P2P Request:** Hospital A directly contacts Hospital C over a raw TCP socket to secure a ventilator.
6. **WebRTC Telemedicine:** Doctors at Hospital A and Hospital B open a WebRTC DataChannel to exchange live patient vital signs.
7. **Failure & Failover:** When Hospital B experiences a simulated outage, Hospital A automatically retries and fails over to Hospital C.
