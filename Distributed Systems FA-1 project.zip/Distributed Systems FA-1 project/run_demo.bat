@echo off
TITLE Distributed Emergency Medical Resource Exchange (FA-1 Demonstration)
COLOR 0B

echo =======================================================================
echo     DISTRIBUTED EMERGENCY MEDICAL RESOURCE EXCHANGE
echo     College FA-1 Distributed Systems Working Prototype
echo =======================================================================
echo.
echo Checking Python installation...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not added to system PATH.
    echo Please install Python 3.9+ and try again.
    pause
    exit /b 1
)

echo Installing/verifying lightweight dependencies (Flask, websockets)...
pip install -r requirements.txt --quiet

echo.
echo Starting all distributed services, nodes, and Web Dashboard...
echo Dashboard will automatically open in your default browser: http://127.0.0.1:5000
echo.
echo Press Ctrl+C in this terminal window to stop the system.
echo =======================================================================
echo.

python main.py

pause
