"""
Individual Node CLI Launcher.
Demonstrates Virtualization and Independent Process Execution (Unit 1).
Run any node in a separate terminal:
  python run_individual_node.py HOSP-MUM-001
  python run_individual_node.py HOSP-MUM-002
"""

import sys
import time
from backend.config import NODES
from backend.node import DistributedNode

def main():
    if len(sys.argv) < 2:
        print("Usage: python run_individual_node.py <NODE_ID>")
        print("Available Node IDs:")
        for nid, info in NODES.items():
            print(f"  - {nid}: {info['name']} (RPC Port: {info['rpc_port']}, P2P Port: {info['p2p_port']})")
        sys.exit(1)

    node_id = sys.argv[1].upper()
    if node_id not in NODES:
        print(f"Error: Node ID '{node_id}' not found in registry.")
        sys.exit(1)

    print("=" * 60)
    print(f" LAUNCHING INDEPENDENT DISTRIBUTED NODE: {node_id}")
    print("=" * 60)

    node = DistributedNode(node_id)
    node.start()

    print(f" Node {node_id} is running independently.")
    print(" Press Ctrl+C to stop this node process.")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping node...")
        node.stop()
        print("Node terminated.")

if __name__ == "__main__":
    main()
