"""
Automated Comprehensive Test Suite for Distributed Medical Resource Exchange.
Validates all Unit 1 & Unit 2 features:
- RPC calls
- Message-Oriented Pub/Sub
- Stream-Oriented WebSocket
- Direct P2P TCP Sockets
- Fault Tolerance (Timeout, Retry, Failover)
- Local SQLite Database State Isolation
"""

import sys
import os
import time
import unittest

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.config import NODES
from backend.database import init_all_dbs, get_node_resources, check_resource_availability
from backend.node import DistributedNode
from backend.messaging.broker import MessageBroker
from backend.rpc.rpc_client import RPCClient
from backend.p2p.p2p_node import P2PClient
from backend.fault_tolerance.fault_manager import FaultToleranceManager

class TestDistributedSystem(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        print("\n--- Booting Test Distributed System ---")
        init_all_dbs(reset=True)

        cls.broker = MessageBroker()
        cls.broker.start()

        cls.nodes = {}
        for nid in NODES:
            node = DistributedNode(nid)
            node.start()
            cls.nodes[nid] = node

        time.sleep(1.0)
        print("--- All test nodes and broker booted ---\n")

    @classmethod
    def tearDownClass(cls):
        print("\n--- Tearing Down Test Distributed System ---")
        for node in cls.nodes.values():
            node.stop()
        cls.broker.stop()
        print("--- Teardown complete ---")

    def test_01_local_database_isolation(self):
        """Test that each node has its own isolated resources."""
        hosp_a_res = get_node_resources("HOSP-MUM-001")
        blood_res = get_node_resources("BLOOD-MUM-001")
        
        self.assertTrue(any(r["resource_type"] == "ICU_BED" for r in hosp_a_res))
        self.assertTrue(any(r["resource_type"] == "BLOOD_O_NEG" for r in blood_res))
        # Blood bank should NOT have ICU beds in its local DB
        self.assertFalse(any(r["resource_type"] == "ICU_BED" for r in blood_res))
        print(" [TEST PASS] Local database isolation verified.")

    def test_02_xml_rpc_communication(self):
        """Test Remote Procedure Call (RPC) between Hospital A and Hospital B."""
        # Query
        res_avail = RPCClient.check_availability("HOSP-MUM-002", "ICU_BED")
        self.assertNotIn("error", res_avail)
        self.assertEqual(res_avail.get("status"), "AVAILABLE")
        initial_qty = res_avail.get("quantity")

        # Request allocation
        res_alloc = RPCClient.request_resource("HOSP-MUM-002", "HOSP-MUM-001", "ICU_BED", 1)
        self.assertNotIn("error", res_alloc)
        self.assertTrue(res_alloc.get("success"))
        self.assertEqual(res_alloc.get("remaining_quantity"), initial_qty - 1)
        print(f" [TEST PASS] XML-RPC verified (Tx: {res_alloc.get('transaction_id')}).")

    def test_03_message_oriented_pubsub(self):
        """Test Message-Oriented Pub/Sub Broker asynchronous broadcast."""
        time.sleep(0.5)
        entry = self.broker.publish_direct(
            sender="HOSP-MUM-001",
            topic="EMERGENCY_BROADCAST",
            message="URGENT: O-negative blood required",
            priority="CRITICAL"
        )
        self.assertEqual(entry["from"], "HOSP-MUM-001")
        self.assertTrue(len(entry["delivered_to"]) >= 2)
        print(f" [TEST PASS] Pub/Sub Broadcast verified (Delivered to {len(entry['delivered_to'])} nodes).")

    def test_04_direct_p2p_socket(self):
        """Test Direct P2P raw TCP socket communication without broker."""
        res = P2PClient.send_direct_request(
            from_node_id="HOSP-MUM-001",
            to_node_id="HOSP-MUM-003",
            resource_type="VENTILATOR",
            quantity=1
        )
        self.assertTrue(res.get("success"))
        self.assertEqual(res.get("status"), "CONFIRMED")
        self.assertEqual(res.get("to"), "HOSP-MUM-003")
        print(f" [TEST PASS] Direct P2P raw TCP Socket communication verified.")

    def test_05_fault_tolerance_timeout_retry_failover(self):
        """Test Fault Tolerance: Hospital B offline -> Timeout -> Retry -> Failover to Hospital C."""
        # Take Hospital B offline
        self.nodes["HOSP-MUM-002"].set_online_status(False)

        res = FaultToleranceManager.execute_with_failover(
            requester_id="HOSP-MUM-001",
            primary_node_id="HOSP-MUM-002",
            backup_node_ids=["HOSP-MUM-003"],
            resource_type="ICU_BED",
            quantity=1,
            max_retries=2,
            timeout=0.6
        )

        self.assertTrue(res.get("success"))
        self.assertEqual(res.get("strategy"), "FAILOVER_SUCCESS")
        self.assertEqual(res.get("failed_primary"), "HOSP-MUM-002")
        self.assertEqual(res.get("serviced_by"), "HOSP-MUM-003")
        self.assertEqual(res.get("serviced_by_name"), "Hospital C (City Care Hospital)")
        self.assertIsNotNone(res.get("transaction_id"))
        print(" [TEST PASS] Fault tolerance (Timeout -> Retry -> Failover) successfully verified.")

    def test_06_failover_backup_exhaustion(self):
        """Test Fault Tolerance when backup node also has insufficient stock."""
        self.nodes["HOSP-MUM-002"].set_online_status(False)

        # Request huge quantity that backup node does not have
        res = FaultToleranceManager.execute_with_failover(
            requester_id="HOSP-MUM-001",
            primary_node_id="HOSP-MUM-002",
            backup_node_ids=["HOSP-MUM-003"],
            resource_type="ICU_BED",
            quantity=999,
            max_retries=1,
            timeout=0.4
        )

        self.nodes["HOSP-MUM-002"].set_online_status(True)

        self.assertFalse(res.get("success"))
        self.assertEqual(res.get("strategy"), "EXHAUSTED")
        self.assertIn("Failover attempted", res.get("message", ""))
        print(" [TEST PASS] Failover backup exhaustion handled gracefully.")

if __name__ == "__main__":
    unittest.main()
