"""
Comprehensive Live System Verification Script.
Tests:
- Web Dashboard and Telemedicine HTML Pages
- Medical Network Resource Search and Allocation APIs (RPC)
- Emergency Broadcast API (Pub/Sub)
- Inter-Facility Communication API (Direct P2P TCP Socket)
- Network Resilience and Failover API (Fault Tolerance)
- WebSocket Continuous Resource Streaming (Port 8765)
- WebRTC Peer Signaling (Port 8766)
"""

import urllib.request
import json
import asyncio
import websockets
import time
import sys

BASE_URL = "http://127.0.0.1:5000"

def test_http(name, url, method="GET", data=None):
    try:
        req = urllib.request.Request(url, method=method)
        if data is not None:
            req.add_header('Content-Type', 'application/json')
            body = json.dumps(data).encode('utf-8')
            res = urllib.request.urlopen(req, data=body, timeout=5)
        else:
            res = urllib.request.urlopen(req, timeout=5)
        
        status = res.getcode()
        content = res.read().decode('utf-8')
        print(f" [PASS] {name} -> Status: {status}")
        return True, json.loads(content) if content.startswith('{') or content.startswith('[') else content
    except Exception as e:
        print(f" [FAIL] {name} -> Error: {e}")
        return False, str(e)

async def test_websocket_stream():
    try:
        uri = "ws://127.0.0.1:8765"
        async with websockets.connect(uri) as ws:
            msg = await asyncio.wait_for(ws.recv(), timeout=4)
            data = json.loads(msg)
            print(f" [PASS] Live Resource Stream (Port 8765) -> Received snapshot Seq #{data.get('seq')}, ICU Beds: {data.get('summary', {}).get('icu_beds')}")
            return True
    except Exception as e:
        print(f" [FAIL] Live Resource Stream (Port 8765) -> Error: {e}")
        return False

async def test_websocket_signaling():
    try:
        uri = "ws://127.0.0.1:8766"
        async with websockets.connect(uri) as ws:
            await ws.send(json.dumps({"type": "join", "peer_id": "test_facility_peer"}))
            msg = await asyncio.wait_for(ws.recv(), timeout=4)
            data = json.loads(msg)
            print(f" [PASS] Telemedicine Signaling Server (Port 8766) -> Registered successfully: {data.get('type')}")
            return True
    except Exception as e:
        print(f" [FAIL] Telemedicine Signaling Server (Port 8766) -> Error: {e}")
        return False

def main():
    print("\n=======================================================")
    print(" VERIFYING EMERGENCY MEDICAL RESOURCE EXCHANGE SYSTEM")
    print("=======================================================\n")

    # 1. UI Pages
    print("--- 1. Testing Web Pages ---")
    test_http("Main Dashboard Page", f"{BASE_URL}/")
    test_http("Hospital A Telemedicine Page", f"{BASE_URL}/webrtc/hospital_a")
    test_http("Hospital B Telemedicine Page", f"{BASE_URL}/webrtc/hospital_b")

    # 2. Medical Network Status
    print("\n--- 2. Testing Medical Network APIs ---")
    test_http("Medical Facilities Directory", f"{BASE_URL}/api/nodes")
    test_http("System Inventory Reset", f"{BASE_URL}/api/system/reset", method="POST")

    # 3. Emergency Resource Search & Allocation (RPC)
    print("\n--- 3. Testing Emergency Resource Search & Allocation (RPC) ---")
    ok, search_res = test_http(
        "Search Network for ICU Bed", 
        f"{BASE_URL}/api/resource/search", 
        method="POST", 
        data={"requester_id": "HOSP-MUM-001", "resource_type": "ICU_BED", "quantity": 1}
    )
    if ok and isinstance(search_res, dict) and search_res.get("results"):
        target_node = search_res["results"][0]["node_id"]
        test_http(
            "Request & Reserve ICU Bed",
            f"{BASE_URL}/api/resource/request",
            method="POST",
            data={"requester_id": "HOSP-MUM-001", "target_node_id": target_node, "resource_type": "ICU_BED", "quantity": 1}
        )

    # 4. Emergency Broadcast (Pub/Sub)
    print("\n--- 4. Testing Emergency Alert Broadcast (Pub/Sub) ---")
    test_http(
        "Broadcast Urgent Blood Alert",
        f"{BASE_URL}/api/alert/broadcast",
        method="POST",
        data={"sender": "HOSP-MUM-001", "topic": "EMERGENCY_BROADCAST", "message": "URGENT: O-negative blood required", "priority": "CRITICAL"}
    )

    # 5. Direct Inter-Facility Message (P2P TCP)
    print("\n--- 5. Testing Direct Facility Communication (P2P TCP) ---")
    test_http(
        "Direct TCP Facility Message",
        f"{BASE_URL}/api/facility/message",
        method="POST",
        data={"from_node": "HOSP-MUM-001", "to_node": "HOSP-MUM-003", "resource_type": "VENTILATOR", "quantity": 1, "message": "Confirm ventilator readiness"}
    )

    # 6. Network Resilience (Fault Tolerance Failover)
    print("\n--- 6. Testing Network Resilience & Failover ---")
    test_http(
        "Simulate Outage & Automated Failover",
        f"{BASE_URL}/api/resilience/test",
        method="POST",
        data={"requester_id": "HOSP-MUM-001", "primary_node": "HOSP-MUM-002", "backup_node": "HOSP-MUM-003", "resource_type": "ICU_BED"}
    )

    # 7. WebSockets
    print("\n--- 7. Testing Real-Time WebSockets ---")
    asyncio.run(test_websocket_stream())
    asyncio.run(test_websocket_signaling())

    print("\n=======================================================")
    print(" ALL LIVE VERIFICATIONS COMPLETED SUCCESSFULLY!")
    print("=======================================================\n")

if __name__ == "__main__":
    main()
