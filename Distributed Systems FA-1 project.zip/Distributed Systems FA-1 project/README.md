# Distributed Emergency Medical Resource Exchange 🏥⚡
### College FA-1 Distributed Systems Working Prototype

A lightweight, robust, and fully working prototype of a **Peer-Cooperating Hybrid Distributed System** built in Python, demonstrating all core concepts from **Unit 1** and **Unit 2** of the Distributed Systems syllabus.

---

## 🏗️ System Architecture

```
                       +--------------------------------------------------+
                       |       Web Dashboard & Scenario Controller        |
                       |             (Flask Web Server :5000)             |
                       +--------------------------------------------------+
                                                 |
    +--------------------------------------------+--------------------------------------------+
    |                                            |                                            |
    v (XML-RPC Calls)                            v (WebSocket Stream :8765)                   v (WebRTC Signaling :8766)
+---------------------------------------------------------------------------------------------------------+
|                                        MIDDLEWARE LAYER                                                 |
|  - XML-RPC Communication Layer (Ports 8001-8005)                                                        |
|  - Message-Oriented Pub/Sub Broker (Port 8500)                                                          |
|  - Stream-Oriented WebSocket Telemetry Server (Port 8765)                                               |
|  - Direct P2P Raw TCP Socket Mesh (Ports 9001-9005)                                                     |
|  - Fault Tolerance Manager (Timeout -> Retry 1 & 2 -> Failover)                                         |
+---------------------------------------------------------------------------------------------------------+
    |                     |                     |                     |                    |
    v                     v                     v                     v                    v
+---------------+  +---------------+  +---------------+  +---------------+  +---------------+
|  Hospital A   |  |  Hospital B   |  |  Hospital C   |  |  Blood Bank   |  |   Ambulance   |
| HOSP-MUM-001  |  | HOSP-MUM-002  |  | HOSP-MUM-003  |  | BLOOD-MUM-001 |  |  AMB-MUM-001  |
| RPC: 8001     |  | RPC: 8002     |  | RPC: 8003     |  | RPC: 8004     |  | RPC: 8005     |
| P2P: 9001     |  | P2P: 9002     |  | P2P: 9003     |  | P2P: 9004     |  | P2P: 9005     |
| Local DB:     |  | Local DB:     |  | Local DB:     |  | Local DB:     |  | Local DB:     |
| hosp_a.db     |  | hosp_b.db     |  | hosp_c.db     |  | blood_bank.db |  | ambulance.db  |
+---------------+  +---------------+  +---------------+  +---------------+  +---------------+
```

---

## 🚀 Quick Start (Fast Setup for Demo)

### Prerequisites
- Python 3.9+ installed
- Web browser (Chrome, Edge, Firefox)

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```
*(Only `Flask` and `websockets` are required. All other modules use Python's built-in standard library!)*

### Step 2: Run the Prototype
On **Windows**, double-click:
```bat
run_demo.bat
```
Or run directly from terminal:
```bash
python main.py
```

### Step 3: Open the Dashboard
Navigate to:
```
http://127.0.0.1:5000
```
*(The browser should open automatically on startup!)*

---

## 🎯 10-Step Live Demonstration Script for Professor

Follow this exact step-by-step procedure during your viva evaluation:

1. **Explain the Distributed Nature (Unit 1):**
   - Point to the **"Connected Distributed Nodes"** table.
   - Mention that each node (`Hospital A`, `Hospital B`, `Hospital C`, `Blood Bank`, `Ambulance`) runs as an independent process with dedicated ports and an isolated local SQLite database (no central bottleneck DB).

2. **Demonstrate Stream-Oriented Communication (Unit 2):**
   - Point to the **"Aggregated Resource Telemetry"** counters.
   - Show the green **"LIVE WS STREAM"** badge and explain that telemetry is pushed continuously every 2.5 seconds via WebSocket (Port 8765) without client polling.

3. **Execute Remote Procedure Call (RPC) (Unit 2):**
   - Click the **"Run RPC Request"** button.
   - Observe Hospital A executing `checkResourceAvailability('ICU_BED')` followed by `requestResource()` on Hospital B over XML-RPC (Port 8002).
   - Point to the transaction ID (`TX-...`) generated in Hospital B's local database.

4. **Demonstrate Message-Oriented Pub/Sub Broadcast (Unit 2):**
   - Click the **"Broadcast Emergency"** button.
   - Watch Hospital A publish `"URGENT: O-negative blood required"` to the Pub/Sub broker (Port 8500).
   - Show in the log that the message is delivered asynchronously to multiple subscribers (`Blood Bank` and `Hospital C`) at once.

5. **Demonstrate Direct Peer-to-Peer (P2P) Messaging (Unit 2):**
   - Click the **"Send P2P Message"** button.
   - Explain to the professor: *"Hospital A connects directly to Hospital C on TCP Port 9003 to transfer a Ventilator, completely bypassing the message broker."*
   - Show the direct TCP ACK confirmation in the log.

6. **Demonstrate Fault Tolerance: Timeout $\rightarrow$ Retry $\rightarrow$ Failover (Unit 2):**
   - Click the **"Test Fault Tolerance"** button.
   - Watch the live log trace:
     - Hospital B is marked OFFLINE.
     - Hospital A sends request $\rightarrow$ **Socket Timeout detected**.
     - **Retry 1** executed $\rightarrow$ fails.
     - **Retry 2** executed $\rightarrow$ fails.
     - Automated **FAILOVER** triggered to backup node `Hospital C`.
     - Hospital C confirms the ICU bed allocation!

7. **Demonstrate Distributed Multimedia & WebRTC (Unit 1 & Unit 2):**
   - Click **"Launch WebRTC Demo"**.
   - Two peer windows will pop up (`Hospital A` and `Hospital B`).
   - Click **"Connect to Hospital B"** on Hospital A's window.
   - Show the state transitioning through Signaling $\rightarrow$ ICE Exchange $\rightarrow$ **`RTCDataChannel OPEN (P2P READY)`**.
   - Click **"Transfer Request"** and send live peer-to-peer data packets across browsers.

8. **Show the Model of Distributed Computation (Unit 1):**
   - Point out the step-by-step distinction in the terminal log between:
     - **Local Computation Events** (checking local DB, updating inventory).
     - **Communication Events** (transmitting messages across network sockets).

9. **Show Naming, Identifiers & Addresses (Unit 2):**
   - Show the Node Table:
     - **Identifier:** `HOSP-MUM-001`
     - **Name:** `Hospital A (General Hospital)`
     - **Address:** `127.0.0.1:8001` (RPC) / `127.0.0.1:9001` (P2P).

10. **Explain Virtualization & Process Independence (Unit 1):**
    - Explain that in production, each node process can be deployed into independent Docker containers or Virtual Machines across physical clouds.

---

## 💻 Running Nodes Independently in Separate Terminals

If your professor asks: *"Can you prove these nodes are actually independent processes and not just hardcoded threads?"*

Open separate command prompts and run:
```bash
# Terminal 1: Hospital A
python run_individual_node.py HOSP-MUM-001

# Terminal 2: Hospital B
python run_individual_node.py HOSP-MUM-002

# Terminal 3: Central Blood Bank
python run_individual_node.py BLOOD-MUM-001
```

---

## 🧪 Automated Testing

To run the complete automated test suite verifying all 5 distributed mechanisms:
```bash
python tests/test_all_features.py
```
*Expected Output: `Ran 5 tests in ~3.1s - OK`*

---

## 📂 Project Structure

```
distributed-medical-exchange/
├── backend/
│   ├── config.py                 # Node registry, port mappings & host settings
│   ├── database.py               # Local SQLite database managers per node
│   ├── node.py                   # Autonomous node class (RPC + P2P + PubSub)
│   ├── rpc/
│   │   ├── rpc_server.py         # Threaded XML-RPC server implementation
│   │   └── rpc_client.py         # XML-RPC client with timeout & error handling
│   ├── messaging/
│   │   ├── broker.py             # Pub/Sub Message Broker (asynchronous topic broadcasts)
│   │   └── pubsub_client.py      # Subscriber/Publisher client for nodes
│   ├── streaming/
│   │   └── stream_server.py      # WebSocket stream server for live telemetry (every 2.5s)
│   ├── p2p/
│   │   └── p2p_node.py           # Direct raw TCP socket mesh (no broker)
│   └── fault_tolerance/
│       └── fault_manager.py      # Timeout -> Retry -> Failover logic
├── frontend/
│   ├── templates/
│   │   ├── index.html            # Unified interactive Web Dashboard
│   │   ├── hospital_a.html       # WebRTC Hospital A Terminal
│   │   └── hospital_b.html       # WebRTC Hospital B Terminal
│   └── static/
│       ├── css/style.css         # Modern emergency UI styles
│       └── js/
│           ├── dashboard.js       # Live stream receiver & interactive demo triggers
│           └── webrtc_client.js  # RTCDataChannel connection handler
├── webrtc/
│   └── signaling_server.py       # WebSocket signaling server for SDP/ICE exchange
├── tests/
│   └── test_all_features.py      # Automated comprehensive test suite
├── main.py                       # Single-file master orchestrator & Flask web server
├── run_individual_node.py        # CLI helper to launch individual nodes separately
├── run_demo.bat                  # 1-Click Windows execution script
├── requirements.txt              # Minimal dependencies (Flask, websockets)
├── UNIT_MAPPING.md               # Complete syllabus-to-code mapping
├── VIVA.md                       # 24 concise Viva Q&As for FA-1
└── README.md                     # This documentation
```

---

## 🛠️ Common Errors & Easy Fixes

| Issue | Cause | Fix |
|-------|-------|-----|
| `Address already in use` | A previous instance of `main.py` is still running in background. | Close all python terminal windows or run `taskkill /F /IM python.exe` in cmd. |
| `WebSocket connection failed` | Stream or Signaling server hasn't finished booting. | Wait 2 seconds and refresh the browser (`F5`). |
| `No module named flask` | Dependencies not installed in current environment. | Run `pip install -r requirements.txt`. |
| `Popup blocked` | Browser blocked WebRTC popup windows. | Click the URL bar icon to **Allow Popups** from `127.0.0.1`. |
