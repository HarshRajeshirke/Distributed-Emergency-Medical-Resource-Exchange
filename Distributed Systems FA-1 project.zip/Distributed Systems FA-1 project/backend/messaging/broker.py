"""
Message-Oriented Communication: Publish/Subscribe Message Broker.
Demonstrates Asynchronous Message-Oriented Middleware (Unit 2).
Enables decoupled, multi-destination asynchronous event broadcasting.
"""

import socket
import threading
import json
import time
import datetime
from collections import defaultdict
from backend.config import BROKER_HOST, BROKER_PORT

class MessageBroker:
    def __init__(self, host=BROKER_HOST, port=BROKER_PORT):
        self.host = host
        self.port = port
        self.server_socket = None
        self.is_running = False
        self.thread = None
        
        # topic -> set of subscriber sockets
        self.subscribers = defaultdict(set)
        # socket -> node_id
        self.client_node_ids = {}
        # socket -> set of topics
        self.client_topics = defaultdict(set)
        # Lock for thread-safety
        self.lock = threading.Lock()
        
        # In-memory message history for live visualization
        self.message_history = []

    def start(self):
        """Start the Pub/Sub broker server."""
        if self.is_running:
            return
        
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(10)
        self.is_running = True

        self.thread = threading.Thread(target=self._listen_loop, daemon=True)
        self.thread.start()
        print(f" [Message Broker] Pub/Sub Broker active on tcp://{self.host}:{self.port}")

    def _listen_loop(self):
        while self.is_running:
            try:
                client_sock, addr = self.server_socket.accept()
                client_thread = threading.Thread(target=self._handle_client, args=(client_sock, addr), daemon=True)
                client_thread.start()
            except Exception:
                break

    def _handle_client(self, client_sock: socket.socket, addr):
        buffer = ""
        while self.is_running:
            try:
                data = client_sock.recv(4096)
                if not data:
                    break
                buffer += data.decode("utf-8")
                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    if line.strip():
                        self._process_command(client_sock, line.strip())
            except Exception:
                break
        
        self._disconnect_client(client_sock)

    def _process_command(self, client_sock: socket.socket, raw_line: str):
        try:
            payload = json.loads(raw_line)
            action = payload.get("action", "").upper()

            if action == "SUBSCRIBE":
                node_id = payload.get("node_id", "UNKNOWN")
                topic = payload.get("topic", "ALL")
                with self.lock:
                    self.subscribers[topic].add(client_sock)
                    self.client_node_ids[client_sock] = node_id
                    self.client_topics[client_sock].add(topic)
                
                resp = {"status": "SUBSCRIBED", "topic": topic, "node_id": node_id}
                client_sock.sendall((json.dumps(resp) + "\n").encode("utf-8"))

            elif action == "PUBLISH":
                # Asynchronous multi-node broadcast
                sender = payload.get("from", "ANONYMOUS")
                topic = payload.get("topic", "EMERGENCY_BROADCAST")
                message = payload.get("message", "")
                priority = payload.get("priority", "HIGH")
                timestamp = datetime.datetime.now().strftime("%H:%M:%S")

                broadcast_msg = {
                    "event": "MESSAGE_RECEIVED",
                    "from": sender,
                    "topic": topic,
                    "message": message,
                    "priority": priority,
                    "timestamp": timestamp
                }

                delivered_to = []
                with self.lock:
                    targets = set(self.subscribers.get(topic, set())) | set(self.subscribers.get("ALL", set()))
                    for sub_sock in list(targets):
                        if sub_sock != client_sock:
                            try:
                                sub_sock.sendall((json.dumps(broadcast_msg) + "\n").encode("utf-8"))
                                sub_node = self.client_node_ids.get(sub_sock, "UNKNOWN")
                                delivered_to.append(sub_node)
                            except Exception:
                                self._disconnect_client(sub_sock)

                # Record in history
                history_entry = {
                    "from": sender,
                    "topic": topic,
                    "message": message,
                    "priority": priority,
                    "timestamp": timestamp,
                    "delivered_to": delivered_to
                }
                self.message_history.append(history_entry)
                if len(self.message_history) > 50:
                    self.message_history.pop(0)

                # Send confirmation back to publisher
                ack = {"status": "PUBLISHED", "delivered_count": len(delivered_to), "subscribers": delivered_to}
                client_sock.sendall((json.dumps(ack) + "\n").encode("utf-8"))

        except Exception as e:
            err = {"status": "ERROR", "message": str(e)}
            try:
                client_sock.sendall((json.dumps(err) + "\n").encode("utf-8"))
            except Exception:
                pass

    def _disconnect_client(self, client_sock: socket.socket):
        with self.lock:
            for topic, subs in self.subscribers.items():
                subs.discard(client_sock)
            self.client_node_ids.pop(client_sock, None)
            self.client_topics.pop(client_sock, None)
        try:
            client_sock.close()
        except Exception:
            pass

    def publish_direct(self, sender: str, topic: str, message: str, priority: str = "HIGH"):
        """Direct publish method callable internally by the system."""
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        broadcast_msg = {
            "event": "MESSAGE_RECEIVED",
            "from": sender,
            "topic": topic,
            "message": message,
            "priority": priority,
            "timestamp": timestamp
        }

        delivered_to = []
        with self.lock:
            targets = set(self.subscribers.get(topic, set())) | set(self.subscribers.get("ALL", set()))
            for sub_sock in list(targets):
                try:
                    sub_sock.sendall((json.dumps(broadcast_msg) + "\n").encode("utf-8"))
                    sub_node = self.client_node_ids.get(sub_sock, "UNKNOWN")
                    delivered_to.append(sub_node)
                except Exception:
                    self._disconnect_client(sub_sock)

        history_entry = {
            "from": sender,
            "topic": topic,
            "message": message,
            "priority": priority,
            "timestamp": timestamp,
            "delivered_to": delivered_to
        }
        self.message_history.append(history_entry)
        return history_entry

    def get_history(self):
        return list(self.message_history)

    def stop(self):
        self.is_running = False
        if self.server_socket:
            try:
                self.server_socket.close()
            except Exception:
                pass
