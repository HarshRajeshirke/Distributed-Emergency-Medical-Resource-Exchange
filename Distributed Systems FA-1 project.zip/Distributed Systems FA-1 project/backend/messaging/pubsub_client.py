"""
Pub/Sub Client for Distributed Nodes.
Connects to Message Broker, subscribes to topics, and handles async event reception.
"""

import socket
import threading
import json
import time
from backend.config import BROKER_HOST, BROKER_PORT

class PubSubClient:
    def __init__(self, node_id: str, host=BROKER_HOST, port=BROKER_PORT, on_message_callback=None):
        self.node_id = node_id
        self.host = host
        self.port = port
        self.on_message_callback = on_message_callback
        self.sock = None
        self.is_connected = False
        self.listen_thread = None
        self.subscribed_topics = set()

    def connect(self):
        """Establish connection with the message broker."""
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.connect((self.host, self.port))
            self.is_connected = True
            self.listen_thread = threading.Thread(target=self._listen, daemon=True)
            self.listen_thread.start()
            return True
        except Exception as e:
            self.is_connected = False
            return False

    def subscribe(self, topic: str):
        """Subscribe this node to a specific topic."""
        if not self.is_connected:
            if not self.connect():
                return False
        
        req = {
            "action": "SUBSCRIBE",
            "node_id": self.node_id,
            "topic": topic
        }
        try:
            self.sock.sendall((json.dumps(req) + "\n").encode("utf-8"))
            self.subscribed_topics.add(topic)
            return True
        except Exception:
            return False

    def publish(self, topic: str, message: str, priority: str = "HIGH"):
        """Publish an asynchronous message to the broker."""
        if not self.is_connected:
            if not self.connect():
                return {"error": "BROKER_UNREACHABLE"}
        
        req = {
            "action": "PUBLISH",
            "from": self.node_id,
            "topic": topic,
            "message": message,
            "priority": priority
        }
        try:
            self.sock.sendall((json.dumps(req) + "\n").encode("utf-8"))
            return {"status": "SENT"}
        except Exception as e:
            return {"error": str(e)}

    def _listen(self):
        buffer = ""
        while self.is_connected:
            try:
                data = self.sock.recv(4096)
                if not data:
                    break
                buffer += data.decode("utf-8")
                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    if line.strip():
                        msg = json.loads(line.strip())
                        if msg.get("event") == "MESSAGE_RECEIVED":
                            if self.on_message_callback:
                                self.on_message_callback(self.node_id, msg)
            except Exception:
                break
        self.is_connected = False

    def disconnect(self):
        self.is_connected = False
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
