"""
XML-RPC Server Implementation for Distributed Nodes.
Demonstrates Remote Procedure Call (RPC) in Distributed Systems (Unit 2).
Exposes checkResourceAvailability, requestResource, and getNodeStatus.
"""

from xmlrpc.server import SimpleXMLRPCServer
from socketserver import ThreadingMixIn
import threading
from backend.database import check_resource_availability, allocate_resource, get_node_resources, log_event
from backend.config import NODES

class ThreadedXMLRPCServer(ThreadingMixIn, SimpleXMLRPCServer):
    """Threaded XML-RPC Server allowing concurrent requests."""
    daemon_threads = True
    allow_reuse_address = True

class NodeRPCServer:
    def __init__(self, node_id: str, host: str = None, port: int = None):
        self.node_id = node_id
        cfg = NODES[node_id]
        self.host = host or cfg["host"]
        self.port = port or cfg["rpc_port"]
        self.node_name = cfg["name"]
        self.node_type = cfg["type"]
        self.server = None
        self.thread = None
        self.is_running = False
        self.is_online = True  # Can be toggled for fault simulation

    def checkResourceAvailability(self, resource_type: str):
        """
        RPC Function 1: checkResourceAvailability
        Invoked remotely by another node (e.g. Hospital A -> Hospital B).
        """
        if not self.is_online:
            raise Exception(f"Node {self.node_id} is currently OFFLINE / unreachable")
        
        log_event(self.node_id, "RPC_RECEIVED", f"RPC checkResourceAvailability received for '{resource_type}'")
        res = check_resource_availability(self.node_id, resource_type)
        return res

    def requestResource(self, requester_id: str, resource_type: str, quantity: int = 1):
        """
        RPC Function 2: requestResource
        Remotely requests and reserves a resource on this node.
        """
        if not self.is_online:
            raise Exception(f"Node {self.node_id} is currently OFFLINE / unreachable")
        
        log_event(self.node_id, "RPC_RECEIVED", f"RPC requestResource received from {requester_id} for {quantity}x {resource_type}")
        result = allocate_resource(self.node_id, requester_id, resource_type, quantity)
        return result

    def getNodeStatus(self):
        """
        RPC Function 3: getNodeStatus
        Returns the operational status and local resource catalog of this node.
        """
        if not self.is_online:
            return {
                "node_id": self.node_id,
                "name": self.node_name,
                "type": self.node_type,
                "status": "OFFLINE",
                "resources": []
            }
        
        resources = get_node_resources(self.node_id)
        return {
            "node_id": self.node_id,
            "name": self.node_name,
            "type": self.node_type,
            "status": "ONLINE",
            "host": self.host,
            "rpc_port": self.port,
            "resources": resources
        }

    def start(self):
        """Start the RPC server in a background thread."""
        if self.is_running:
            return
        
        self.server = ThreadedXMLRPCServer(
            (self.host, self.port),
            logRequests=False,
            allow_none=True
        )
        # Register remote functions
        self.server.register_function(self.checkResourceAvailability, "checkResourceAvailability")
        self.server.register_function(self.requestResource, "requestResource")
        self.server.register_function(self.getNodeStatus, "getNodeStatus")
        self.server.register_introspection_functions()

        self.is_running = True
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        print(f" [RPC Server] {self.node_id} ({self.node_name}) listening on http://{self.host}:{self.port}")

    def stop(self):
        """Stop the RPC server."""
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            self.is_running = False
            print(f" [RPC Server] {self.node_id} stopped.")
