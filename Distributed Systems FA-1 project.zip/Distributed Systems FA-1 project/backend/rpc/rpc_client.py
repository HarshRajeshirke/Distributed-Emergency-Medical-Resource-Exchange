"""
XML-RPC Client Wrapper for Distributed Nodes.
Handles remote method invocation, error handling, and socket timeouts.
"""

import xmlrpc.client
import socket
from backend.config import NODES

class TimeoutTransport(xmlrpc.client.Transport):
    """Custom XML-RPC Transport with socket timeout."""
    def __init__(self, timeout=2.0, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.timeout = timeout

    def make_connection(self, host):
        conn = super().make_connection(host)
        conn.timeout = self.timeout
        return conn

class RPCClient:
    """Helper client to invoke RPC methods on distributed nodes."""

    @staticmethod
    def get_proxy(target_node_id: str, timeout: float = 2.0):
        node_cfg = NODES.get(target_node_id)
        if not node_cfg:
            raise ValueError(f"Target node '{target_node_id}' not found in registry.")
        
        url = f"http://{node_cfg['host']}:{node_cfg['rpc_port']}"
        transport = TimeoutTransport(timeout=timeout)
        proxy = xmlrpc.client.ServerProxy(url, transport=transport, allow_none=True)
        return proxy

    @classmethod
    def check_availability(cls, target_node_id: str, resource_type: str, timeout: float = 2.0):
        """Invoke checkResourceAvailability(resource_type) remotely."""
        try:
            proxy = cls.get_proxy(target_node_id, timeout=timeout)
            return proxy.checkResourceAvailability(resource_type)
        except (socket.timeout, TimeoutError):
            return {"error": "TIMEOUT", "message": f"Connection to {target_node_id} timed out after {timeout}s"}
        except ConnectionRefusedError:
            return {"error": "CONNECTION_REFUSED", "message": f"Node {target_node_id} is OFFLINE or unreachable"}
        except Exception as e:
            return {"error": "RPC_ERROR", "message": str(e)}

    @classmethod
    def request_resource(cls, target_node_id: str, requester_id: str, resource_type: str, quantity: int = 1, timeout: float = 2.0):
        """Invoke requestResource(requester_id, resource_type, quantity) remotely."""
        try:
            proxy = cls.get_proxy(target_node_id, timeout=timeout)
            return proxy.requestResource(requester_id, resource_type, quantity)
        except (socket.timeout, TimeoutError):
            return {"error": "TIMEOUT", "message": f"Connection to {target_node_id} timed out after {timeout}s"}
        except ConnectionRefusedError:
            return {"error": "CONNECTION_REFUSED", "message": f"Node {target_node_id} is OFFLINE or unreachable"}
        except Exception as e:
            return {"error": "RPC_ERROR", "message": str(e)}

    @classmethod
    def get_node_status(cls, target_node_id: str, timeout: float = 2.0):
        """Invoke getNodeStatus() remotely."""
        try:
            proxy = cls.get_proxy(target_node_id, timeout=timeout)
            return proxy.getNodeStatus()
        except Exception as e:
            node_cfg = NODES.get(target_node_id, {})
            return {
                "node_id": target_node_id,
                "name": node_cfg.get("name", target_node_id),
                "type": node_cfg.get("type", "Unknown"),
                "status": "OFFLINE",
                "resources": [],
                "error": str(e)
            }
