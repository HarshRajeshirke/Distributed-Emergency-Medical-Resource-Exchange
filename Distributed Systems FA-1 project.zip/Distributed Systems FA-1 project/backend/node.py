"""
Autonomous Distributed Node Implementation.
Encapsulates an independent node with its own local database,
RPC server, P2P socket listener, and Pub/Sub subscriber.
"""

from backend.config import NODES
from backend.database import init_node_db, get_node_resources, log_event
from backend.rpc.rpc_server import NodeRPCServer
from backend.p2p.p2p_node import P2PListener
from backend.messaging.pubsub_client import PubSubClient

class DistributedNode:
    def __init__(self, node_id: str, on_message_callback=None):
        if node_id not in NODES:
            raise ValueError(f"Unknown node ID: {node_id}")
        
        self.node_id = node_id
        self.cfg = NODES[node_id]
        self.name = self.cfg["name"]
        self.type = self.cfg["type"]
        self.host = self.cfg["host"]
        self.rpc_port = self.cfg["rpc_port"]
        self.p2p_port = self.cfg["p2p_port"]
        self.on_message_callback = on_message_callback

        # Initialize local database
        init_node_db(self.node_id)

        # Components
        self.rpc_server = NodeRPCServer(self.node_id, self.host, self.rpc_port)
        self.p2p_listener = P2PListener(self.node_id)
        self.pubsub_client = PubSubClient(self.node_id, on_message_callback=self._handle_pubsub_message)
        
        self.is_online = True

    def _handle_pubsub_message(self, node_id, message_data):
        log_event(self.node_id, "ASYNC_MSG_RECEIVED", f"PubSub message on topic '{message_data.get('topic')}': {message_data.get('message')}")
        if self.on_message_callback:
            self.on_message_callback(node_id, message_data)

    def start(self):
        """Start all services for this independent node."""
        self.rpc_server.start()
        self.p2p_listener.start()
        self.pubsub_client.connect()
        # Subscribe to relevant topics
        self.pubsub_client.subscribe("EMERGENCY_BROADCAST")
        self.pubsub_client.subscribe("BLOOD_REQUEST")
        self.pubsub_client.subscribe("ALL")
        self.is_online = True
        print(f" [+] Distributed Node '{self.node_id}' ({self.name}) is fully ONLINE.")

    def set_online_status(self, is_online: bool):
        """Toggle online/offline status to simulate node failures for fault tolerance."""
        self.is_online = is_online
        self.rpc_server.is_online = is_online
        status_str = "ONLINE" if is_online else "OFFLINE (SIMULATED FAILURE)"
        log_event(self.node_id, "STATUS_CHANGE", f"Node status changed to {status_str}")
        print(f" [!] Node {self.node_id} status updated to: {status_str}")

    def get_status(self):
        return {
            "node_id": self.node_id,
            "name": self.name,
            "type": self.type,
            "host": self.host,
            "rpc_port": self.rpc_port,
            "p2p_port": self.p2p_port,
            "is_online": self.is_online,
            "resources": get_node_resources(self.node_id) if self.is_online else []
        }

    def stop(self):
        self.rpc_server.stop()
        self.p2p_listener.stop()
        self.pubsub_client.disconnect()
        self.is_online = False
        print(f" [-] Distributed Node '{self.node_id}' stopped.")
