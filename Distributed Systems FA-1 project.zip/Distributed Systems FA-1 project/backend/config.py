"""
Configuration and Registry for Distributed Emergency Medical Resource Exchange.
Demonstrates Names, Identifiers, and Addresses in Distributed Systems.
"""

import os

# Base directory
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

# Host Configuration
DEFAULT_HOST = "127.0.0.1"

# Service Ports (Centralized Registry)
BROKER_HOST = DEFAULT_HOST
BROKER_PORT = 8500

STREAM_HOST = DEFAULT_HOST
STREAM_PORT = 8765

SIGNALING_HOST = DEFAULT_HOST
SIGNALING_PORT = 8766

DASHBOARD_HOST = DEFAULT_HOST
DASHBOARD_PORT = 5000

# Node Registry: Identifier -> Node Attributes
# Clearly shows: Node ID, Node Type, IP Address, RPC Port, P2P Port, Local DB
NODES = {
    "HOSP-MUM-001": {
        "id": "HOSP-MUM-001",
        "name": "Hospital A (General Hospital)",
        "type": "General Hospital",
        "host": DEFAULT_HOST,
        "rpc_port": 8001,
        "p2p_port": 9001,
        "db_path": os.path.join(DATA_DIR, "node_hosp_a.db"),
        "initial_resources": [
            {"resource_type": "ICU_BED", "name": "ICU Bed", "quantity": 2, "unit": "beds", "status": "AVAILABLE", "location": "Ward-1"},
            {"resource_type": "OXYGEN", "name": "Oxygen Cylinder", "quantity": 10, "unit": "cylinders", "status": "AVAILABLE", "location": "Store-A"},
            {"resource_type": "VENTILATOR", "name": "Ventilator", "quantity": 2, "unit": "units", "status": "AVAILABLE", "location": "ICU-2"},
            {"resource_type": "MEDICINE", "name": "Emergency Medicine Kit", "quantity": 40, "unit": "kits", "status": "AVAILABLE", "location": "Pharmacy"}
        ]
    },
    "HOSP-MUM-002": {
        "id": "HOSP-MUM-002",
        "name": "Hospital B (Super Specialty Hospital)",
        "type": "Super Specialty Hospital",
        "host": DEFAULT_HOST,
        "rpc_port": 8002,
        "p2p_port": 9002,
        "db_path": os.path.join(DATA_DIR, "node_hosp_b.db"),
        "initial_resources": [
            {"resource_type": "ICU_BED", "name": "ICU Bed", "quantity": 3, "unit": "beds", "status": "AVAILABLE", "location": "ICU-East"},
            {"resource_type": "VENTILATOR", "name": "Ventilator", "quantity": 4, "unit": "units", "status": "AVAILABLE", "location": "ICU-East"},
            {"resource_type": "MEDICINE", "name": "Emergency Medicine Kit", "quantity": 60, "unit": "kits", "status": "AVAILABLE", "location": "Pharmacy-B"},
            {"resource_type": "OXYGEN", "name": "Oxygen Cylinder", "quantity": 15, "unit": "cylinders", "status": "AVAILABLE", "location": "Store-B"}
        ]
    },
    "HOSP-MUM-003": {
        "id": "HOSP-MUM-003",
        "name": "Hospital C (City Care Hospital)",
        "type": "City Care Hospital",
        "host": DEFAULT_HOST,
        "rpc_port": 8003,
        "p2p_port": 9003,
        "db_path": os.path.join(DATA_DIR, "node_hosp_c.db"),
        "initial_resources": [
            {"resource_type": "ICU_BED", "name": "ICU Bed", "quantity": 1, "unit": "beds", "status": "AVAILABLE", "location": "ICU-Central"},
            {"resource_type": "VENTILATOR", "name": "Ventilator", "quantity": 3, "unit": "units", "status": "AVAILABLE", "location": "Ward-C"},
            {"resource_type": "OXYGEN", "name": "Oxygen Cylinder", "quantity": 20, "unit": "cylinders", "status": "AVAILABLE", "location": "Store-C"},
            {"resource_type": "MEDICINE", "name": "Emergency Medicine Kit", "quantity": 30, "unit": "kits", "status": "AVAILABLE", "location": "Pharmacy-C"}
        ]
    },
    "BLOOD-MUM-001": {
        "id": "BLOOD-MUM-001",
        "name": "Central Blood Bank",
        "type": "Blood Bank",
        "host": DEFAULT_HOST,
        "rpc_port": 8004,
        "p2p_port": 9004,
        "db_path": os.path.join(DATA_DIR, "node_blood_bank.db"),
        "initial_resources": [
            {"resource_type": "BLOOD_O_POS", "name": "O+ Blood Units", "quantity": 25, "unit": "units", "status": "AVAILABLE", "location": "ColdStorage-1"},
            {"resource_type": "BLOOD_O_NEG", "name": "O- Blood Units (Universal)", "quantity": 8, "unit": "units", "status": "AVAILABLE", "location": "ColdStorage-2"},
            {"resource_type": "BLOOD_A_POS", "name": "A+ Blood Units", "quantity": 18, "unit": "units", "status": "AVAILABLE", "location": "ColdStorage-1"},
            {"resource_type": "BLOOD_B_POS", "name": "B+ Blood Units", "quantity": 20, "unit": "units", "status": "AVAILABLE", "location": "ColdStorage-1"}
        ]
    },
    "AMB-MUM-001": {
        "id": "AMB-MUM-001",
        "name": "Emergency Ambulance Hub",
        "type": "Ambulance Centre",
        "host": DEFAULT_HOST,
        "rpc_port": 8005,
        "p2p_port": 9005,
        "db_path": os.path.join(DATA_DIR, "node_ambulance.db"),
        "initial_resources": [
            {"resource_type": "AMBULANCE_BASIC", "name": "Basic Life Support Ambulance", "quantity": 4, "unit": "vehicles", "status": "AVAILABLE", "location": "Bay-North"},
            {"resource_type": "AMBULANCE_ICU", "name": "Advanced ICU Ambulance", "quantity": 2, "unit": "vehicles", "status": "AVAILABLE", "location": "Bay-South"}
        ]
    }
}
