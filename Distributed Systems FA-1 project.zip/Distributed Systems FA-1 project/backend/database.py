"""
Local SQLite Database Manager for Distributed Nodes.
Each node strictly manages its own local SQLite database file,
enforcing decentralized autonomous data ownership in the distributed system.
"""

import sqlite3
import datetime
import uuid
import threading
from backend.config import NODES

# Thread-safe database connection helper
_db_locks = {}

def _get_lock(node_id: str):
    if node_id not in _db_locks:
        _db_locks[node_id] = threading.Lock()
    return _db_locks[node_id]

def get_connection(node_id: str):
    node_cfg = NODES.get(node_id)
    if not node_cfg:
        raise ValueError(f"Unknown node identifier: {node_id}")
    db_path = node_cfg["db_path"]
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_node_db(node_id: str, reset: bool = False):
    """Initialize the schema and initial local resources for a node."""
    node_cfg = NODES.get(node_id)
    if not node_cfg:
        return

    with _get_lock(node_id):
        conn = get_connection(node_id)
        cursor = conn.cursor()

        if reset:
            cursor.execute("DROP TABLE IF EXISTS resources")
            cursor.execute("DROP TABLE IF EXISTS allocations")
            cursor.execute("DROP TABLE IF EXISTS local_events")

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS resources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_type TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unit TEXT NOT NULL,
                status TEXT NOT NULL,
                location TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS allocations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_id TEXT NOT NULL,
                requester_id TEXT NOT NULL,
                resource_type TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                status TEXT NOT NULL,
                timestamp TEXT NOT NULL
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS local_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT NOT NULL,
                description TEXT NOT NULL,
                timestamp TEXT NOT NULL
            )
        """)

        # Insert default resources if empty
        cursor.execute("SELECT COUNT(*) as count FROM resources")
        if cursor.fetchone()["count"] == 0:
            now = datetime.datetime.now().isoformat()
            for r in node_cfg.get("initial_resources", []):
                cursor.execute("""
                    INSERT INTO resources (resource_type, name, quantity, unit, status, location, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (r["resource_type"], r["name"], r["quantity"], r["unit"], r["status"], r["location"], now))
            
            cursor.execute("""
                INSERT INTO local_events (event_type, description, timestamp)
                VALUES (?, ?, ?)
            """, ("INIT", f"Node {node_id} local database initialized with default resources.", now))

        conn.commit()
        conn.close()

def init_all_dbs(reset: bool = False):
    """Initialize databases for all registered distributed nodes."""
    for node_id in NODES:
        init_node_db(node_id, reset=reset)

def get_node_resources(node_id: str):
    """Query all local resources for a specific node."""
    with _get_lock(node_id):
        conn = get_connection(node_id)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM resources")
        rows = cursor.fetchall()
        resources = [dict(row) for row in rows]
        conn.close()
        return resources

def check_resource_availability(node_id: str, resource_type: str):
    """
    Local event: Check if the resource exists locally and has available quantity.
    Demonstrates local computation event in distributed computing model.
    """
    with _get_lock(node_id):
        conn = get_connection(node_id)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM resources WHERE resource_type = ?", (resource_type.upper(),))
        row = cursor.fetchone()
        
        now = datetime.datetime.now().strftime("%H:%M:%S")
        if row and row["quantity"] > 0:
            res = {
                "available": True,
                "status": "AVAILABLE",
                "quantity": row["quantity"],
                "unit": row["unit"],
                "name": row["name"],
                "node_id": node_id
            }
            cursor.execute("""
                INSERT INTO local_events (event_type, description, timestamp)
                VALUES (?, ?, ?)
            """, ("LOCAL_QUERY", f"Local check for {resource_type}: {row['quantity']} {row['unit']} AVAILABLE", now))
        else:
            res = {
                "available": False,
                "status": "UNAVAILABLE",
                "quantity": 0 if not row else row["quantity"],
                "unit": "units" if not row else row["unit"],
                "name": resource_type,
                "node_id": node_id
            }
            cursor.execute("""
                INSERT INTO local_events (event_type, description, timestamp)
                VALUES (?, ?, ?)
            """, ("LOCAL_QUERY", f"Local check for {resource_type}: UNAVAILABLE", now))

        conn.commit()
        conn.close()
        return res

def allocate_resource(node_id: str, requester_id: str, resource_type: str, quantity: int = 1):
    """
    Local state mutation: Deducts local resource and logs transaction.
    """
    with _get_lock(node_id):
        conn = get_connection(node_id)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM resources WHERE resource_type = ?", (resource_type.upper(),))
        row = cursor.fetchone()
        
        now = datetime.datetime.now().strftime("%H:%M:%S")
        iso_now = datetime.datetime.now().isoformat()
        
        if row and row["quantity"] >= quantity:
            new_qty = row["quantity"] - quantity
            new_status = "AVAILABLE" if new_qty > 0 else "EXHAUSTED"
            
            cursor.execute("""
                UPDATE resources 
                SET quantity = ?, status = ?, updated_at = ?
                WHERE resource_type = ?
            """, (new_qty, new_status, iso_now, resource_type.upper()))
            
            tx_id = f"TX-{uuid.uuid4().hex[:8].upper()}"
            cursor.execute("""
                INSERT INTO allocations (transaction_id, requester_id, resource_type, quantity, status, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (tx_id, requester_id, resource_type.upper(), quantity, "CONFIRMED", iso_now))
            
            cursor.execute("""
                INSERT INTO local_events (event_type, description, timestamp)
                VALUES (?, ?, ?)
            """, ("LOCAL_ALLOCATION", f"Allocated {quantity} {row['unit']} of {resource_type} to {requester_id}. Remaining: {new_qty}", now))
            
            conn.commit()
            conn.close()
            return {
                "success": True,
                "status": "CONFIRMED",
                "transaction_id": tx_id,
                "allocated_quantity": quantity,
                "remaining_quantity": new_qty,
                "resource_name": row["name"],
                "node_id": node_id
            }
        else:
            tx_id = f"TX-{uuid.uuid4().hex[:8].upper()}"
            cursor.execute("""
                INSERT INTO allocations (transaction_id, requester_id, resource_type, quantity, status, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (tx_id, requester_id, resource_type.upper(), quantity, "REJECTED_INSUFFICIENT", iso_now))
            
            cursor.execute("""
                INSERT INTO local_events (event_type, description, timestamp)
                VALUES (?, ?, ?)
            """, ("LOCAL_REJECT", f"Rejected request from {requester_id} for {quantity} {resource_type} (Insufficient stock)", now))
            
            conn.commit()
            conn.close()
            return {
                "success": False,
                "status": "REJECTED",
                "transaction_id": tx_id,
                "message": "Insufficient resource quantity",
                "node_id": node_id
            }

def log_event(node_id: str, event_type: str, description: str):
    """Log an event directly into a node's local database."""
    with _get_lock(node_id):
        conn = get_connection(node_id)
        cursor = conn.cursor()
        now = datetime.datetime.now().strftime("%H:%M:%S")
        cursor.execute("""
            INSERT INTO local_events (event_type, description, timestamp)
            VALUES (?, ?, ?)
        """, (event_type, description, now))
        conn.commit()
        conn.close()

def get_node_allocations(node_id: str):
    """Get all past resource transactions for a node."""
    with _get_lock(node_id):
        conn = get_connection(node_id)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM allocations ORDER BY id DESC LIMIT 20")
        rows = cursor.fetchall()
        allocations = [dict(row) for row in rows]
        conn.close()
        return allocations
