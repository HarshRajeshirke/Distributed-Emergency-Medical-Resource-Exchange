# Streaming package initializer
