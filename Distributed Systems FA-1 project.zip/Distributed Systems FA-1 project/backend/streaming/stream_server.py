"""
Stream-Oriented Communication: WebSocket Resource Telemetry Server.
Demonstrates Stream-Oriented Communication in Distributed Systems (Unit 2).
Continuously pushes periodic real-time resource state snapshots to clients (2-3 seconds).
"""

import asyncio
import websockets
import json
import threading
import datetime
from backend.config import STREAM_HOST, STREAM_PORT, NODES
from backend.database import get_node_resources

class ResourceStreamServer:
    def __init__(self, host=STREAM_HOST, port=STREAM_PORT, interval=2.5):
        self.host = host
        self.port = port
        self.interval = interval
        self.clients = set()
        self.is_running = False
        self.loop = None
        self.thread = None
        self.sequence_number = 0
        self.latest_snapshot = {}

    def _collect_live_snapshot(self):
        """Collect current resource state from all local node databases."""
        self.sequence_number += 1
        now_time = datetime.datetime.now().strftime("%H:%M:%S")
        
        total_icu = 0
        total_vent = 0
        total_o_pos = 0
        total_o_neg = 0
        total_oxygen = 0
        total_amb = 0

        node_snapshots = {}

        for node_id, cfg in NODES.items():
            resources = get_node_resources(node_id)
            node_snapshots[node_id] = {
                "name": cfg["name"],
                "type": cfg["type"],
                "resources": resources
            }

            for r in resources:
                rtype = r["resource_type"]
                qty = r["quantity"]
                if rtype == "ICU_BED":
                    total_icu += qty
                elif rtype == "VENTILATOR":
                    total_vent += qty
                elif rtype == "BLOOD_O_POS":
                    total_o_pos += qty
                elif rtype == "BLOOD_O_NEG":
                    total_o_neg += qty
                elif rtype == "OXYGEN":
                    total_oxygen += qty
                elif "AMBULANCE" in rtype:
                    total_amb += qty

        snapshot = {
            "type": "STREAM_UPDATE",
            "seq": self.sequence_number,
            "timestamp": now_time,
            "summary": {
                "icu_beds": total_icu,
                "ventilators": total_vent,
                "blood_o_pos": total_o_pos,
                "blood_o_neg": total_o_neg,
                "oxygen": total_oxygen,
                "ambulances": total_amb
            },
            "nodes": node_snapshots
        }
        self.latest_snapshot = snapshot
        return snapshot

    async def _handler(self, websocket):
        """Handle incoming WebSocket client connections."""
        self.clients.add(websocket)
        # Send immediate initial snapshot
        try:
            initial_data = json.dumps(self._collect_live_snapshot())
            await websocket.send(initial_data)
        except Exception:
            pass

        try:
            async for _ in websocket:
                # Keep-alive or handle incoming client pings
                pass
        except Exception:
            pass
        finally:
            self.clients.discard(websocket)

    async def _broadcast_loop(self):
        """Periodic streaming loop emitting live telemetry every 2-3 seconds."""
        while self.is_running:
            try:
                snapshot = self._collect_live_snapshot()
                payload = json.dumps(snapshot)
                
                if self.clients:
                    # Broadcast to all connected clients
                    dead_clients = set()
                    for ws in list(self.clients):
                        try:
                            await ws.send(payload)
                        except Exception:
                            dead_clients.add(ws)
                    self.clients.difference_update(dead_clients)
            except Exception as e:
                print(f"[Stream Server Error] {e}")
            
            await asyncio.sleep(self.interval)

    def _run_server(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        
        async def main():
            server = await websockets.serve(self._handler, self.host, self.port)
            print(f" [Stream Server] WebSocket Streaming active on ws://{self.host}:{self.port}")
            await self._broadcast_loop()
            await server.wait_closed()

        self.loop.run_until_complete(main())

    def start(self):
        if self.is_running:
            return
        self.is_running = True
        self.thread = threading.Thread(target=self._run_server, daemon=True)
        self.thread.start()

    def get_latest_snapshot(self):
        if not self.latest_snapshot:
            return self._collect_live_snapshot()
        return self.latest_snapshot
