"""
Peer-to-Peer (P2P) Direct Socket Communication.
Demonstrates P2P Messaging in Distributed Systems (Unit 2).
Nodes communicate directly over raw TCP sockets without any central broker or intermediary.
"""

import socket
import threading
import json
import datetime
from backend.config import NODES
from backend.database import check_resource_availability, allocate_resource, log_event

class P2PListener:
    """Runs a dedicated TCP socket server on each node for direct peer-to-peer messaging."""
    def __init__(self, node_id: str):
        self.node_id = node_id
        cfg = NODES[node_id]
        self.host = cfg["host"]
        self.port = cfg["p2p_port"]
        self.server_socket = None
        self.is_running = False
        self.thread = None
        self.p2p_log = []

    def start(self):
        if self.is_running:
            return
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(5)
        self.is_running = True

        self.thread = threading.Thread(target=self._listen_loop, daemon=True)
        self.thread.start()
        print(f" [P2P Node] {self.node_id} direct TCP listener active on tcp://{self.host}:{self.port}")

    def _listen_loop(self):
        while self.is_running:
            try:
                client_sock, addr = self.server_socket.accept()
                client_thread = threading.Thread(target=self._handle_peer, args=(client_sock, addr), daemon=True)
                client_thread.start()
            except Exception:
                break

    def _handle_peer(self, client_sock: socket.socket, addr):
        try:
            data = client_sock.recv(4096).decode("utf-8")
            if not data:
                return
            
            payload = json.loads(data)
            action = payload.get("action")
            sender = payload.get("from", "UNKNOWN")
            resource_type = payload.get("resource_type", "VENTILATOR")
            quantity = payload.get("quantity", 1)

            now = datetime.datetime.now().strftime("%H:%M:%S")

            if action == "P2P_QUERY":
                # Check local DB
                avail = check_resource_availability(self.node_id, resource_type)
                if avail["available"] and avail["quantity"] >= quantity:
                    # Allocate directly via P2P
                    alloc = allocate_resource(self.node_id, sender, resource_type, quantity)
                    response = {
                        "action": "P2P_RESPONSE",
                        "status": "CONFIRMED",
                        "from": self.node_id,
                        "resource_type": resource_type,
                        "quantity": quantity,
                        "message": f"Direct P2P allocation confirmed ({quantity} {resource_type})",
                        "timestamp": now
                    }
                else:
                    response = {
                        "action": "P2P_RESPONSE",
                        "status": "UNAVAILABLE",
                        "from": self.node_id,
                        "resource_type": resource_type,
                        "message": f"Resource {resource_type} not available at peer {self.node_id}",
                        "timestamp": now
                    }
                
                # Send direct response
                client_sock.sendall(json.dumps(response).encode("utf-8"))

                # Wait for ACK from requester
                ack_data = client_sock.recv(4096).decode("utf-8")
                if ack_data:
                    ack_payload = json.loads(ack_data)
                    log_event(self.node_id, "P2P_ACK_RECEIVED", f"P2P ACK from {sender}: {ack_payload.get('status')}")

        except Exception as e:
            err = {"status": "ERROR", "message": str(e)}
            try:
                client_sock.sendall(json.dumps(err).encode("utf-8"))
            except Exception:
                pass
        finally:
            try:
                client_sock.close()
            except Exception:
                pass

    def stop(self):
        self.is_running = False
        if self.server_socket:
            try:
                self.server_socket.close()
            except Exception:
                pass

class P2PClient:
    """Client to send direct peer-to-peer TCP requests to another node without broker."""
    @staticmethod
    def send_direct_request(from_node_id: str, to_node_id: str, resource_type: str, quantity: int = 1, timeout: float = 3.0):
        target_cfg = NODES.get(to_node_id)
        if not target_cfg:
            return {"error": "INVALID_TARGET", "message": f"Node {to_node_id} not in registry"}

        host = target_cfg["host"]
        port = target_cfg["p2p_port"]
        steps = []
        now = datetime.datetime.now().strftime("%H:%M:%S")

        steps.append(f"[{now}] [P2P] Establishing direct TCP connection {from_node_id} -> {to_node_id} on {host}:{port}")

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)

        try:
            sock.connect((host, port))
            
            # Step 1: Send Request directly to peer
            req_payload = {
                "action": "P2P_QUERY",
                "from": from_node_id,
                "to": to_node_id,
                "resource_type": resource_type,
                "quantity": quantity
            }
            sock.sendall(json.dumps(req_payload).encode("utf-8"))
            steps.append(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] [P2P] Direct query sent for {quantity}x {resource_type} (No Broker Used)")

            # Step 2: Receive direct peer response
            resp_data = sock.recv(4096).decode("utf-8")
            if not resp_data:
                return {"error": "EMPTY_RESPONSE", "steps": steps}

            resp = json.loads(resp_data)
            steps.append(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] [P2P] Received direct response from {to_node_id}: {resp.get('status')}")

            # Step 3: Send P2P ACK back to peer
            ack_payload = {
                "action": "P2P_ACK",
                "status": "CONFIRMED",
                "from": from_node_id,
                "timestamp": datetime.datetime.now().strftime("%H:%M:%S")
            }
            sock.sendall(json.dumps(ack_payload).encode("utf-8"))
            steps.append(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] [P2P] Direct TCP ACK sent from {from_node_id} to {to_node_id}")

            log_event(from_node_id, "P2P_SUCCESS", f"Direct P2P transaction completed with {to_node_id} for {quantity}x {resource_type}")

            return {
                "success": True,
                "status": resp.get("status"),
                "from": from_node_id,
                "to": to_node_id,
                "resource_type": resource_type,
                "quantity": quantity,
                "details": resp,
                "steps": steps
            }

        except socket.timeout:
            steps.append(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] [P2P_ERROR] Connection to {to_node_id} timed out")
            return {"error": "TIMEOUT", "steps": steps}
        except ConnectionRefusedError:
            steps.append(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] [P2P_ERROR] Peer {to_node_id} connection refused (Node Offline)")
            return {"error": "CONNECTION_REFUSED", "steps": steps}
        except Exception as e:
            steps.append(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] [P2P_ERROR] {str(e)}")
            return {"error": "P2P_ERROR", "message": str(e), "steps": steps}
        finally:
            try:
                sock.close()
            except Exception:
                pass
