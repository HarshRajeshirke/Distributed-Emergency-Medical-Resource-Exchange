# Fault Tolerance package initializer
