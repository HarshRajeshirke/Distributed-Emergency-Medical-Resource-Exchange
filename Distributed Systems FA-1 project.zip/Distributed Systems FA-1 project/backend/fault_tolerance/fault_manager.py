"""
Fault Tolerance Manager: Timeout, Retry, and Failover.
Demonstrates Fault Tolerance and High Availability in Distributed Systems (Unit 2).
Handles node crashes gracefully via automated failover policies.
"""

import time
import datetime
from backend.rpc.rpc_client import RPCClient
from backend.config import NODES
from backend.database import log_event

class FaultToleranceManager:
    @staticmethod
    def execute_with_failover(requester_id: str, primary_node_id: str, backup_node_ids: list, resource_type: str, quantity: int = 1, max_retries: int = 2, timeout: float = 1.0):
        """
        Executes a resilient resource allocation request:
        1. Attempt primary node.
        2. Detect timeout / connection failure.
        3. Execute Retries (Retry 1, Retry 2).
        4. Trigger Failover to backup node.
        """
        logs = []
        
        def add_log(category: str, text: str):
            ts = datetime.datetime.now().strftime("%H:%M:%S")
            entry = f"[{ts}] [{category}] {text}"
            logs.append(entry)
            print(entry)

        primary_name = NODES.get(primary_node_id, {}).get('name', primary_node_id)
        
        add_log("ROUTING", f"REQUEST START: {requester_id} requesting {quantity}x {resource_type}")
        add_log("ROUTING", f"PRIMARY TARGET: {primary_node_id} ({primary_name})")

        primary_succeeded = False
        primary_response = None

        # Attempt Primary Node with Retries
        for attempt in range(1, max_retries + 2):
            if attempt == 1:
                add_log("RESOURCE", f"Checking availability at primary target {primary_node_id} (Timeout={timeout}s)...")
            else:
                retry_num = attempt - 1
                add_log("FAULT", f"RETRY {retry_num}: Re-attempting connection to {primary_node_id}...")

            res = RPCClient.check_availability(primary_node_id, resource_type, timeout=timeout)

            if "error" not in res:
                # Primary responded
                add_log("RESOURCE", f"{primary_node_id} responded: {resource_type} = {res.get('status')} (Qty: {res.get('quantity')})")
                if res.get("available") and res.get("quantity") >= quantity:
                    # Allocate
                    alloc_res = RPCClient.request_resource(primary_node_id, requester_id, resource_type, quantity, timeout=timeout)
                    if "error" not in alloc_res and alloc_res.get("success"):
                        tx_id = alloc_res.get('transaction_id')
                        add_log("RESOURCE", f"RESOURCE ALLOCATED: {quantity}x {resource_type} confirmed by {primary_node_id}")
                        add_log("RESOURCE", f"TRANSACTION CREATED: {tx_id}")
                        primary_succeeded = True
                        primary_response = alloc_res
                        break
                    else:
                        add_log("RESOURCE", f"{primary_node_id} allocation failed: {alloc_res.get('message', 'Unknown error')}")
                else:
                    add_log("RESOURCE", f"{primary_node_id} has insufficient {resource_type}. Initiating search on backup nodes.")
                    break
            else:
                err_type = res["error"]
                if attempt == 1:
                    add_log("FAULT", f"PRIMARY OFFLINE: {primary_node_id} is unreachable ({err_type})")
                else:
                    add_log("FAULT", f"RETRY FAILED: {primary_node_id} still unresponsive")
                if attempt <= max_retries:
                    time.sleep(0.4)

        if primary_succeeded:
            return {
                "success": True,
                "strategy": "PRIMARY_SUCCESS",
                "serviced_by": primary_node_id,
                "serviced_by_name": primary_name,
                "resource_type": resource_type,
                "quantity": quantity,
                "transaction_id": primary_response.get("transaction_id"),
                "details": primary_response,
                "logs": logs
            }

        # FAILOVER TRIGGERED
        add_log("FAILOVER", f"FAILOVER: Primary facility {primary_node_id} unavailable. Initiating automated failover routing.")
        
        for backup_id in backup_node_ids:
            backup_name = NODES.get(backup_id, {}).get('name', backup_id)
            add_log("FAILOVER", f"BACKUP TARGET: {backup_id} ({backup_name})")
            add_log("RESOURCE", f"RESOURCE CHECK: Querying {backup_id} for {resource_type} availability...")
            
            # Query backup node
            backup_check = RPCClient.check_availability(backup_id, resource_type, timeout=timeout)
            
            if "error" not in backup_check:
                add_log("RESOURCE", f"Backup facility {backup_id} is ONLINE. {resource_type} = {backup_check.get('status')} (Qty: {backup_check.get('quantity')})")
                
                if backup_check.get("available") and backup_check.get("quantity") >= quantity:
                    # Allocate from backup node
                    backup_alloc = RPCClient.request_resource(backup_id, requester_id, resource_type, quantity, timeout=timeout)
                    if "error" not in backup_alloc and backup_alloc.get("success"):
                        tx_id = backup_alloc.get('transaction_id')
                        rem_qty = backup_alloc.get('remaining_quantity')
                        
                        add_log("FAILOVER", f"RESOURCE ALLOCATED: {quantity}x {resource_type} successfully allocated from backup facility {backup_id}")
                        add_log("FAILOVER", f"TRANSACTION CREATED: {tx_id}")
                        
                        log_event(requester_id, "FAILOVER_SUCCESS", f"Allocated {quantity} {resource_type} via failover from {backup_id} (Tx: {tx_id})")
                        
                        return {
                            "success": True,
                            "strategy": "FAILOVER_SUCCESS",
                            "failed_primary": primary_node_id,
                            "failed_primary_name": primary_name,
                            "serviced_by": backup_id,
                            "serviced_by_name": backup_name,
                            "resource_type": resource_type,
                            "quantity": quantity,
                            "transaction_id": tx_id,
                            "remaining_quantity": rem_qty,
                            "details": backup_alloc,
                            "logs": logs
                        }
                    else:
                        add_log("FAILOVER", f"Allocation failed at {backup_id}: {backup_alloc.get('message')}")
                else:
                    add_log("FAILOVER", f"Backup facility {backup_id} has insufficient {resource_type} (Available: {backup_check.get('quantity', 0)})")
            else:
                add_log("FAULT", f"Backup facility {backup_id} also unreachable: {backup_check.get('error')}")

        fail_msg = "Failover attempted, but no suitable backup resource was available."
        add_log("FAULT", fail_msg)
        return {
            "success": False,
            "strategy": "EXHAUSTED",
            "failed_primary": primary_node_id,
            "failed_primary_name": primary_name,
            "serviced_by": None,
            "serviced_by_name": None,
            "resource_type": resource_type,
            "quantity": quantity,
            "message": fail_msg,
            "logs": logs
        }
