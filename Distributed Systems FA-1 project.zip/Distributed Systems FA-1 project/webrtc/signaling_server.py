"""
WebRTC Signaling Server using WebSocket.
Demonstrates Distributed Multimedia Systems (Unit 1) & WebRTC DataChannel (Unit 2).
Exchanges SDP offers, answers, and ICE candidates between browser peers.
"""

import asyncio
import websockets
import json
import threading
from backend.config import SIGNALING_HOST, SIGNALING_PORT

class WebRTCSignalingServer:
    def __init__(self, host=SIGNALING_HOST, port=SIGNALING_PORT):
        self.host = host
        self.port = port
        self.peers = {}  # peer_id -> websocket
        self.is_running = False
        self.loop = None
        self.thread = None

    async def _handler(self, websocket):
        peer_id = None
        try:
            async for raw_msg in websocket:
                data = json.loads(raw_msg)
                msg_type = data.get("type")

                if msg_type == "join":
                    peer_id = data.get("peer_id")
                    self.peers[peer_id] = websocket
                    print(f" [WebRTC Signaling] Peer registered: '{peer_id}'")
                    # Notify current peer list
                    await websocket.send(json.dumps({
                        "type": "joined",
                        "peer_id": peer_id,
                        "peers": list(self.peers.keys())
                    }))
                    # Notify others
                    for p_id, ws in list(self.peers.items()):
                        if p_id != peer_id:
                            try:
                                await ws.send(json.dumps({
                                    "type": "peer_joined",
                                    "peer_id": peer_id
                                }))
                            except Exception:
                                pass

                elif msg_type in ["offer", "answer", "candidate"]:
                    target_peer = data.get("target")
                    if target_peer and target_peer in self.peers:
                        target_ws = self.peers[target_peer]
                        await target_ws.send(json.dumps(data))
                        print(f" [WebRTC Signaling] Relayed '{msg_type}' from '{peer_id}' to '{target_peer}'")

        except Exception as e:
            print(f" [WebRTC Signaling Error] {e}")
        finally:
            if peer_id and peer_id in self.peers:
                del self.peers[peer_id]
                print(f" [WebRTC Signaling] Peer disconnected: '{peer_id}'")
                for p_id, ws in list(self.peers.items()):
                    try:
                        await ws.send(json.dumps({
                            "type": "peer_left",
                            "peer_id": peer_id
                        }))
                    except Exception:
                        pass

    def _run_server(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        
        async def main():
            server = await websockets.serve(self._handler, self.host, self.port)
            print(f" [WebRTC Signaling] Signaling server listening on ws://{self.host}:{self.port}")
            await server.wait_closed()

        self.loop.run_until_complete(main())

    def start(self):
        if self.is_running:
            return
        self.is_running = True
        self.thread = threading.Thread(target=self._run_server, daemon=True)
        self.thread.start()
