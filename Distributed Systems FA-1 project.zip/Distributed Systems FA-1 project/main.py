"""
Main Master Orchestrator and Flask Web Server.
Distributed Emergency Medical Resource Exchange (FA-1 Prototype).

Boots:
1. Message-Oriented Pub/Sub Broker (Port 8500)
2. Stream-Oriented WebSocket Server (Port 8765)
3. WebRTC Signaling Server (Port 8766)
4. 5 Independent Distributed Nodes (RPC: 8001-8005, P2P: 9001-9005)
5. Flask Web Dashboard (Port 5000)
"""

import os
import sys
import time
import json
import queue
import datetime
import threading
import webbrowser
from flask import Flask, render_template, jsonify, request, Response

from backend.config import NODES, DASHBOARD_HOST, DASHBOARD_PORT
from backend.database import init_all_dbs, get_node_allocations
from backend.node import DistributedNode
from backend.messaging.broker import MessageBroker
from backend.streaming.stream_server import ResourceStreamServer
from webrtc.signaling_server import WebRTCSignalingServer
from backend.rpc.rpc_client import RPCClient
from backend.p2p.p2p_node import P2PClient
from backend.fault_tolerance.fault_manager import FaultToleranceManager

# Flask Application setup
template_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "frontend", "templates")
static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "frontend", "static")
app = Flask(__name__, template_folder=template_dir, static_folder=static_dir)

# Global instances
broker = None
stream_server = None
signaling_server = None
node_instances = {}
sse_event_queue = queue.Queue(maxsize=100)

def broadcast_sse(category: str, message: str):
    """Push event log to SSE listeners (dashboard)."""
    ts = datetime.datetime.now().strftime("%H:%M:%S")
    item = {"category": category, "message": message, "timestamp": ts}
    try:
        sse_event_queue.put_nowait(item)
    except Exception:
        pass

def on_node_pubsub_message(node_id, message_data):
    """Callback triggered when a node receives an async pub/sub message."""
    sender = message_data.get("from", "UNKNOWN")
    topic = message_data.get("topic", "")
    msg = message_data.get("message", "")
    broadcast_sse("MESSAGE", f"{node_id} received broadcast from {sender} on [{topic}]: '{msg}'")

# --- Flask Routes ---

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/webrtc/hospital_a")
def webrtc_a():
    return render_template("hospital_a.html")

@app.route("/webrtc/hospital_b")
def webrtc_b():
    return render_template("hospital_b.html")

@app.route("/api/nodes", methods=["GET"])
def api_get_nodes():
    nodes_data = {}
    for node_id, inst in node_instances.items():
        nodes_data[node_id] = inst.get_status()
    return jsonify(nodes_data)

@app.route("/api/nodes/<node_id>/toggle", methods=["POST"])
def api_toggle_node(node_id):
    if node_id not in node_instances:
        return jsonify({"error": "Node not found"}), 404
    data = request.get_json() or {}
    new_state = data.get("is_online", True)
    node_instances[node_id].set_online_status(new_state)
    status_str = "ONLINE" if new_state else "OFFLINE"
    broadcast_sse("FAULT", f"Node {node_id} manually switched {status_str}")
    return jsonify({"node_id": node_id, "is_online": new_state})

@app.route("/api/transactions", methods=["GET"])
def api_get_transactions():
    all_allocs = []
    for node_id in NODES:
        allocs = get_node_allocations(node_id)
        for a in allocs:
            a["node_id"] = node_id
            all_allocs.append(a)
    all_allocs.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
    return jsonify(all_allocs)

@app.route("/api/events/stream")
def sse_stream():
    def event_stream():
        while True:
            try:
                item = sse_event_queue.get(timeout=20.0)
                yield f"data: {json.dumps(item)}\n\n"
            except queue.Empty:
                # Keep-alive ping
                yield ": keepalive\n\n"
    return Response(event_stream(), mimetype="text/event-stream")

# --- Medical Resource Exchange REST API Endpoints ---

@app.route("/api/resource/search", methods=["POST"])
@app.route("/api/demo/rpc_search", methods=["POST"])
def api_resource_search():
    """
    Searches candidate medical facilities for resource availability using XML-RPC.
    """
    data = request.get_json() or {}
    resource_type = data.get("resource_type", "ICU_BED").upper()
    quantity = int(data.get("quantity", 1))
    requester_id = data.get("requester_id", "HOSP-MUM-001")
    preferred_node = data.get("preferred_node", "ANY")

    results = []
    ts = datetime.datetime.now().strftime("%H:%M:%S")

    broadcast_sse("RESOURCE", f"{requester_id} searching network for {quantity}x {resource_type}...")

    candidate_nodes = [preferred_node] if preferred_node in NODES and preferred_node != "ANY" else [nid for nid in NODES if nid != requester_id]

    for target_id in candidate_nodes:
        check_res = RPCClient.check_availability(target_id, resource_type, timeout=1.5)
        if "error" not in check_res and check_res.get("available"):
            target_cfg = NODES.get(target_id, {})
            results.append({
                "node_id": target_id,
                "node_name": target_cfg.get("name", target_id),
                "type": target_cfg.get("type", "Facility"),
                "resource_type": resource_type,
                "quantity": check_res.get("quantity", 0),
                "unit": check_res.get("unit", "units"),
                "status": "AVAILABLE" if check_res.get("quantity", 0) >= quantity else "PARTIAL",
                "sufficient": check_res.get("quantity", 0) >= quantity
            })

    if results:
        broadcast_sse("RESOURCE", f"Resource search completed: Found {len(results)} matching facility/facilities with {resource_type}")
    else:
        broadcast_sse("RESOURCE", f"Resource search completed: No facilities currently have sufficient {resource_type}")

    return jsonify({"success": True, "results": results, "query": {"resource_type": resource_type, "quantity": quantity}})

@app.route("/api/resource/request", methods=["POST"])
@app.route("/api/demo/rpc", methods=["POST"])
def api_resource_request():
    """
    Requests and reserves emergency resources at a target facility via XML-RPC.
    """
    data = request.get_json() or {}
    requester_id = data.get("requester_id", "HOSP-MUM-001")
    target_node_id = data.get("target_node_id", "HOSP-MUM-002")
    resource_type = data.get("resource_type", "ICU_BED").upper()
    quantity = int(data.get("quantity", 1))

    logs = []
    ts = datetime.datetime.now().strftime("%H:%M:%S")

    logs.append(f"[{ts}] [RESOURCE] {requester_id} initiating allocation request to {target_node_id} for {quantity}x {resource_type}...")
    broadcast_sse("RESOURCE", f"{requester_id} sending allocation request to {target_node_id} ({quantity}x {resource_type})")

    # Verify availability first via RPC
    check_res = RPCClient.check_availability(target_node_id, resource_type, timeout=2.0)
    if "error" in check_res:
        logs.append(f"[{ts}] [ALERT] Facility {target_node_id} unreachable: {check_res.get('message')}")
        broadcast_sse("ALERT", f"Facility {target_node_id} unreachable")
        return jsonify({"success": False, "logs": logs, "result": check_res})

    if not check_res.get("available") or check_res.get("quantity", 0) < quantity:
        logs.append(f"[{ts}] [RESOURCE] Insufficient {resource_type} at {target_node_id} (Available: {check_res.get('quantity', 0)})")
        return jsonify({"success": False, "message": "Insufficient resource quantity", "logs": logs, "result": check_res})

    # Execute remote allocation procedure
    alloc_res = RPCClient.request_resource(target_node_id, requester_id, resource_type, quantity, timeout=2.0)
    if alloc_res.get("success"):
        tx_id = alloc_res.get("transaction_id")
        remaining = alloc_res.get("remaining_quantity")
        logs.append(f"[{ts}] [RESOURCE] {target_node_id} CONFIRMED allocation (Transaction ID: {tx_id}). Remaining inventory: {remaining}")
        broadcast_sse("RESOURCE", f"{target_node_id} CONFIRMED {quantity}x {resource_type} for {requester_id} (Tx: {tx_id})")
        return jsonify({"success": True, "logs": logs, "result": alloc_res, "transaction_id": tx_id})
    else:
        logs.append(f"[{ts}] [RESOURCE] Allocation rejected by {target_node_id}: {alloc_res.get('message')}")
        return jsonify({"success": False, "logs": logs, "result": alloc_res})

@app.route("/api/alert/broadcast", methods=["POST"])
@app.route("/api/demo/pubsub", methods=["POST"])
def api_alert_broadcast():
    """
    Broadcasts an asynchronous emergency alert across the medical network using Pub/Sub.
    """
    data = request.get_json() or {}
    sender = data.get("sender", "HOSP-MUM-001")
    topic = data.get("topic", "EMERGENCY_BROADCAST")
    message = data.get("message", "URGENT: O-negative blood required for trauma patient in Emergency Ward-1")
    priority = data.get("priority", "CRITICAL")

    broadcast_sse("ALERT", f"Emergency alert broadcast by {sender} [{topic}]: '{message}'")

    msg_entry = broker.publish_direct(
        sender=sender,
        topic=topic,
        message=message,
        priority=priority
    )

    return jsonify(msg_entry)

@app.route("/api/facility/message", methods=["POST"])
@app.route("/api/demo/p2p", methods=["POST"])
def api_facility_message():
    """
    Sends a direct point-to-point inter-facility message over raw TCP socket.
    """
    data = request.get_json() or {}
    from_node = data.get("from_node", "HOSP-MUM-001")
    to_node = data.get("to_node", "HOSP-MUM-003")
    resource_type = data.get("resource_type", "VENTILATOR").upper()
    quantity = int(data.get("quantity", 1))
    custom_msg = data.get("message", "Direct inter-facility coordination query")

    broadcast_sse("DIRECT MSG", f"{from_node} opening direct TCP communication link to {to_node} (Port {NODES.get(to_node, {}).get('p2p_port', 9000)})")

    res = P2PClient.send_direct_request(
        from_node_id=from_node,
        to_node_id=to_node,
        resource_type=resource_type,
        quantity=quantity
    )

    if res.get("success"):
        broadcast_sse("DIRECT MSG", f"Direct communication link with {to_node} verified: {res.get('status')} received with ACK")

    return jsonify(res)

@app.route("/api/resilience/test", methods=["POST"])
@app.route("/api/demo/fault_tolerance", methods=["POST"])
def api_resilience_test():
    """
    Tests network resilience and automated failover routing when a primary facility is offline.
    """
    data = request.get_json() or {}
    primary_node = data.get("primary_node", "HOSP-MUM-002")
    backup_node = data.get("backup_node", "HOSP-MUM-003")
    requester = data.get("requester_id", "HOSP-MUM-001")
    resource_type = data.get("resource_type", "ICU_BED")
    quantity = int(data.get("quantity", 1))

    # Temporarily set primary facility offline
    node_instances[primary_node].set_online_status(False)

    res = FaultToleranceManager.execute_with_failover(
        requester_id=requester,
        primary_node_id=primary_node,
        backup_node_ids=[backup_node],
        resource_type=resource_type,
        quantity=quantity,
        max_retries=2,
        timeout=0.8
    )

    # Broadcast all log steps to live stream
    for log_line in res.get("logs", []):
        try:
            parts = log_line.split("] [")
            if len(parts) >= 2:
                cat = parts[1].split("]")[0]
                msg = log_line.split(f"[{cat}] ")[-1]
                broadcast_sse(cat, msg)
        except Exception:
            pass

    # Recover primary facility after test
    time.sleep(1.0)
    node_instances[primary_node].set_online_status(True)
    broadcast_sse("ROUTING", f"Facility {primary_node} restored to ONLINE status")

    return jsonify(res)

@app.route("/api/system/reset", methods=["POST"])
def api_system_reset():
    """Reinitializes all node local databases to default resource counts."""
    init_all_dbs(reset=True)
    broadcast_sse("NETWORK", "All medical facility databases synchronized to initial default inventories.")
    return jsonify({"status": "RESET_SUCCESS"})

# --- Startup Orchestration ---

def start_services():
    global broker, stream_server, signaling_server, node_instances

    print("=" * 70)
    print(" DISTRIBUTED EMERGENCY MEDICAL RESOURCE EXCHANGE (FA-1 PROTOTYPE)")
    print("=" * 70)

    # 1. Initialize local databases
    print("[1/5] Initializing local node SQLite databases...")
    init_all_dbs(reset=False)

    # 2. Start Message Broker
    print("[2/5] Starting Message-Oriented Pub/Sub Broker (Port 8500)...")
    broker = MessageBroker()
    broker.start()

    # 3. Start Stream Server
    print("[3/5] Starting Stream-Oriented WebSocket Server (Port 8765)...")
    stream_server = ResourceStreamServer()
    stream_server.start()

    # 4. Start WebRTC Signaling Server
    print("[4/5] Starting WebRTC Signaling Server (Port 8766)...")
    signaling_server = WebRTCSignalingServer()
    signaling_server.start()

    # 5. Start Independent Distributed Nodes
    print("[5/5] Starting 5 Autonomous Distributed Nodes (RPC: 8001-8005, P2P: 9001-9005)...")
    for node_id in NODES:
        node = DistributedNode(node_id, on_message_callback=on_node_pubsub_message)
        node.start()
        node_instances[node_id] = node

    time.sleep(1.0)
    print("=" * 70)
    print(f" [+] ALL DISTRIBUTED SERVICES ONLINE!")
    print(f" [!] Web Dashboard: http://{DASHBOARD_HOST}:{DASHBOARD_PORT}")
    print("=" * 70)

if __name__ == "__main__":
    start_services()
    
    # Auto-open browser after 1 second
    def open_browser():
        time.sleep(1.5)
        webbrowser.open(f"http://{DASHBOARD_HOST}:{DASHBOARD_PORT}")
    
    threading.Thread(target=open_browser, daemon=True).start()

    # Run Flask Dashboard
    app.run(host=DASHBOARD_HOST, port=DASHBOARD_PORT, debug=False, use_reloader=False)
