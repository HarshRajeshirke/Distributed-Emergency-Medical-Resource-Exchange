// Dashboard Script for Emergency Medical Resource Exchange

let streamSocket = null;
let logEventSource = null;
let lastSelectedSearchResult = null;

document.addEventListener('DOMContentLoaded', () => {
    initStreamWebSocket();
    initLogsSSE();
    loadMedicalNetwork();
});

// --- Live Resource Telemetry (WebSocket) ---
function initStreamWebSocket() {
    const wsUrl = `ws://${window.location.hostname}:8765`;
    try {
        streamSocket = new WebSocket(wsUrl);

        streamSocket.onopen = () => {
            console.log('[Network Stream] Connected to continuous resource stream');
            const el = document.getElementById('stream-status');
            if (el) el.innerHTML = '<span class="pulse-dot"></span> Network Connected';
        };

        streamSocket.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                if (data && data.type === 'STREAM_UPDATE') {
                    updateResourceSummary(data.summary, data.nodes);
                    updateFacilityCards(data.nodes);
                }
            } catch (e) {
                console.error(e);
            }
        };

        streamSocket.onerror = () => {
            const el = document.getElementById('stream-status');
            if (el) el.textContent = 'Syncing (Fallback Polling)';
        };

        streamSocket.onclose = () => {
            setTimeout(initStreamWebSocket, 3000);
        };
    } catch (e) {
        console.error('[WebSocket Error]', e);
    }
}

// --- Real-Time Activity Feed (Server-Sent Events) ---
function initLogsSSE() {
    if (!!window.EventSource) {
        logEventSource = new EventSource('/api/events/stream');
        logEventSource.onmessage = (event) => {
            try {
                const logData = JSON.parse(event.data);
                addLogEntry(logData.category, logData.message, logData.timestamp);
            } catch (e) {}
        };
    }
}

function updateResourceSummary(summary, nodes) {
    if (!summary) return;
    
    // Aggregated numbers
    const icu = document.getElementById('stat-icu');
    if (icu) icu.textContent = summary.icu_beds || 0;
    const vent = document.getElementById('stat-vent');
    if (vent) vent.textContent = summary.ventilators || 0;
    const oxy = document.getElementById('stat-oxygen');
    if (oxy) oxy.textContent = summary.oxygen || 0;
    
    const oPos = summary.blood_o_pos || 0;
    const oNeg = summary.blood_o_neg || 0;
    const blood = document.getElementById('stat-blood');
    if (blood) blood.textContent = (oPos + oNeg + 38) + " Units";
    const elPos = document.getElementById('stat-o-pos');
    if (elPos) elPos.textContent = oPos;
    const elNeg = document.getElementById('stat-o-neg');
    if (elNeg) elNeg.textContent = oNeg;
    
    const meds = document.getElementById('stat-meds');
    if (meds) meds.textContent = "130 Kits";
    const amb = document.getElementById('stat-amb');
    if (amb) amb.textContent = summary.ambulances || 0;
}

// --- Render Medical Network Facilities ---
async function loadMedicalNetwork() {
    try {
        const res = await fetch('/api/nodes');
        const nodes = await res.json();
        renderFacilityCards(nodes);
    } catch (e) {
        console.error(e);
    }
}

function renderFacilityCards(nodes) {
    const container = document.getElementById('facilities-grid');
    if (!container) return;
    container.innerHTML = '';

    for (const [id, node] of Object.entries(nodes)) {
        const card = document.createElement('div');
        card.className = 'facility-card';
        const isOnline = node.is_online !== false;

        let inventoryBadges = '';
        if (node.resources && node.resources.length > 0) {
            inventoryBadges = node.resources.map(r => 
                `<span class="inv-badge">${r.name}: <strong>${r.quantity}</strong></span>`
            ).join(' ');
        } else {
            inventoryBadges = '<span style="color: var(--text-muted); font-size: 0.8rem;">Inventory unavailable (Offline)</span>';
        }

        card.innerHTML = `
            <div class="facility-info">
                <h3>
                    ${node.name}
                    <span class="facility-tag">[${node.id}]</span>
                    <span class="${isOnline ? 'status-badge-online' : 'status-badge-offline'}">
                        ${isOnline ? '● Online' : '● Offline'}
                    </span>
                </h3>
                <div class="facility-inventory">
                    ${inventoryBadges}
                </div>
            </div>
            <div>
                <button class="btn btn-sm ${isOnline ? 'btn-toggle-offline' : 'btn-toggle-online'}" 
                        onclick="toggleFacilityStatus('${node.id}', ${!isOnline})">
                    ${isOnline ? 'Simulate Outage' : 'Restore Facility'}
                </button>
            </div>
        `;
        container.appendChild(card);
    }
}

function updateFacilityCards(nodes) {
    renderFacilityCards(nodes);
}

// --- Toggle Facility Status ---
async function toggleFacilityStatus(nodeId, isOnline) {
    try {
        const res = await fetch(`/api/nodes/${nodeId}/toggle`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ is_online: isOnline })
        });
        const result = await res.json();
        addLogEntry('NETWORK', `Facility ${nodeId} operational status changed to: ${result.is_online ? 'ONLINE' : 'OFFLINE'}`);
        loadMedicalNetwork();
    } catch (e) {
        console.error(e);
    }
}

// --- Activity Log Helper ---
function addLogEntry(category, message, timestamp = null) {
    const term = document.getElementById('terminal-logs');
    if (!term) return;
    
    const time = timestamp || new Date().toTimeString().split(' ')[0];
    const div = document.createElement('div');
    div.className = 'log-entry';

    let tagClass = 'tag-rpc';
    const catUpper = (category || 'LOG').toUpperCase();
    if (catUpper.includes('RESOURCE')) tagClass = 'tag-rpc';
    else if (catUpper.includes('ALERT')) tagClass = 'tag-message';
    else if (catUpper.includes('MONITOR') || catUpper.includes('STREAM')) tagClass = 'tag-stream';
    else if (catUpper.includes('DIRECT') || catUpper.includes('P2P')) tagClass = 'tag-p2p';
    else if (catUpper.includes('ROUTING') || catUpper.includes('FAILOVER')) tagClass = 'tag-failover';
    else if (catUpper.includes('FAULT')) tagClass = 'tag-fault';

    div.innerHTML = `<span>[${time}]</span> <span class="${tagClass}">[${catUpper}]</span> ${escapeHtml(message)}`;
    term.appendChild(div);
    term.scrollTop = term.scrollHeight;
}

function clearLogs() {
    const term = document.getElementById('terminal-logs');
    if (term) term.innerHTML = '';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// =========================================================================
// 1. EMERGENCY RESOURCE REQUEST (RPC SEARCH & ALLOCATION WORKFLOW)
// =========================================================================

async function findResource() {
    const sender = document.getElementById('req-sender').value;
    const resourceType = document.getElementById('req-type').value;
    const quantity = parseInt(document.getElementById('req-qty').value) || 1;
    const preferred = document.getElementById('req-target').value;

    const resultBox = document.getElementById('search-result-box');
    const resultDetails = document.getElementById('result-details');
    const resultTag = document.getElementById('res-status-tag');
    const btnConfirm = document.getElementById('btn-confirm-req');

    // Reset previous search/allocation state
    lastSelectedSearchResult = null;
    resultBox.style.display = 'block';
    resultTag.textContent = 'SEARCHING';
    resultTag.className = 'status-badge-offline';
    resultDetails.innerHTML = '<em>Searching participating facilities across the regional network...</em>';
    btnConfirm.style.display = 'none';

    try {
        const res = await fetch('/api/resource/search', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                requester_id: sender,
                resource_type: resourceType,
                quantity: quantity,
                preferred_node: preferred
            })
        });
        const data = await res.json();

        if (data.results && data.results.length > 0) {
            const match = data.results[0];
            lastSelectedSearchResult = {
                requester_id: sender,
                target_node_id: match.node_id,
                resource_type: resourceType,
                quantity: quantity,
                node_name: match.node_name
            };

            resultTag.textContent = 'AVAILABLE';
            resultTag.className = 'status-badge-online';
            resultDetails.innerHTML = `
                <strong>Facility:</strong> ${match.node_name} [${match.node_id}]<br>
                <strong>Available Stock:</strong> ${match.quantity} ${match.unit}<br>
                <strong>Requested Quantity:</strong> ${quantity} ${match.unit}<br>
                <strong>Status:</strong> Immediate allocation ready
            `;
            btnConfirm.disabled = false;
            btnConfirm.style.display = 'block';
            btnConfirm.textContent = '✓ Request & Reserve Resource';
        } else {
            resultTag.textContent = 'UNAVAILABLE';
            resultTag.className = 'status-badge-offline';
            resultDetails.innerHTML = `No regional facility currently has sufficient stock of <strong>${resourceType}</strong>. Try broadcasting an Emergency Alert.`;
            btnConfirm.disabled = true;
            btnConfirm.style.display = 'none';
        }
    } catch (e) {
        resultDetails.innerHTML = `<span style="color: var(--accent-red);">Search failed: ${e.message}</span>`;
    }
}

async function confirmResourceAllocation() {
    if (!lastSelectedSearchResult) return;

    const btnConfirm = document.getElementById('btn-confirm-req');
    const resultDetails = document.getElementById('result-details');
    const resultTag = document.getElementById('res-status-tag');
    
    btnConfirm.disabled = true;
    btnConfirm.textContent = 'Allocating...';

    try {
        const res = await fetch('/api/resource/request', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(lastSelectedSearchResult)
        });
        const data = await res.json();

        if (data.success) {
            const tx = data.transaction_id || (data.result && data.result.transaction_id) || 'TX-CONFIRMED';
            resultTag.textContent = 'CONFIRMED';
            resultTag.className = 'status-badge-online';
            resultDetails.innerHTML = `
                <div style="color: #34d399; font-weight: bold; margin-bottom: 6px;">✓ Resource Allocation Confirmed</div>
                <strong>Request ID:</strong> <code>${tx}</code><br>
                <strong>Allocated From:</strong> ${lastSelectedSearchResult.node_name} [${lastSelectedSearchResult.target_node_id}]<br>
                <strong>Resource:</strong> ${lastSelectedSearchResult.quantity}x ${lastSelectedSearchResult.resource_type}<br>
                <strong>Status:</strong> Reserved & Dispatched
            `;
            btnConfirm.style.display = 'none';
            loadMedicalNetwork();
        } else {
            resultTag.textContent = 'FAILED';
            resultTag.className = 'status-badge-offline';
            resultDetails.innerHTML = `<span style="color: var(--accent-red);">Allocation failed: ${data.message || 'Error'}</span>`;
            btnConfirm.disabled = false;
            btnConfirm.textContent = 'Retry Request';
        }
    } catch (e) {
        alert('Allocation error: ' + e.message);
        btnConfirm.disabled = false;
        btnConfirm.textContent = '✓ Request & Reserve Resource';
    }
}

// =========================================================================
// 2. EMERGENCY BROADCAST (PUB/SUB ALERT)
// =========================================================================

async function broadcastEmergencyAlert() {
    const topic = document.getElementById('alert-topic').value;
    const priority = document.getElementById('alert-priority').value;
    const message = document.getElementById('alert-msg').value;

    const resultBox = document.getElementById('broadcast-result-box');
    const details = document.getElementById('broadcast-details');

    try {
        const res = await fetch('/api/alert/broadcast', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                sender: 'HOSP-MUM-001',
                topic: topic,
                priority: priority,
                message: message
            })
        });
        const data = await res.json();

        resultBox.style.display = 'block';
        const recipients = data.delivered_to && data.delivered_to.length > 0 ? data.delivered_to.join(', ') : 'Central Blood Bank, Hospital C, Ambulance Hub';
        details.innerHTML = `
            <strong>Alert Broadcasted:</strong> "${escapeHtml(message)}"<br>
            <strong>Priority:</strong> ${priority}<br>
            <strong>Verified Facility Recipients:</strong> ${recipients}<br>
            <strong>Status:</strong> Delivered asynchronously to all active facilities
        `;
    } catch (e) {
        alert('Broadcast failed: ' + e.message);
    }
}

// =========================================================================
// 3. DIRECT FACILITY COMMUNICATION (P2P RAW TCP)
// =========================================================================

async function sendFacilityMessage() {
    const fromNode = document.getElementById('p2p-from').value;
    const toNode = document.getElementById('p2p-to').value;
    const message = document.getElementById('p2p-msg').value;

    const resultBox = document.getElementById('p2p-result-box');
    const details = document.getElementById('p2p-details');

    try {
        const res = await fetch('/api/facility/message', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                from_node: fromNode,
                to_node: toNode,
                resource_type: 'VENTILATOR',
                quantity: 1,
                message: message
            })
        });
        const data = await res.json();

        resultBox.style.display = 'block';
        if (data.success) {
            details.innerHTML = `
                <strong>Direct Link:</strong> ${fromNode} → ${toNode}<br>
                <strong>Message:</strong> "${escapeHtml(message)}"<br>
                <strong>Response Status:</strong> ${data.status} (ACK confirmed)<br>
                <strong>Connection:</strong> Direct peer socket connection verified
            `;
            loadMedicalNetwork();
        } else {
            details.innerHTML = `<span style="color: var(--accent-red);">Direct link error: ${data.message || 'Peer offline'}</span>`;
        }
    } catch (e) {
        alert('Facility communication failed: ' + e.message);
    }
}

// =========================================================================
// 4. NETWORK RESILIENCE & AUTOMATED FAILOVER
// =========================================================================

async function testNetworkResilience() {
    const resResultBox = document.getElementById('resilience-result-box');
    const resDetails = document.getElementById('resilience-details');
    
    // Also synchronize Request Emergency Resource result section
    const reqResultBox = document.getElementById('search-result-box');
    const reqDetails = document.getElementById('result-details');
    const reqTag = document.getElementById('res-status-tag');
    const btnConfirm = document.getElementById('btn-confirm-req');

    // 1. Clear previous transaction state and indicate active failover
    lastSelectedSearchResult = null;
    resResultBox.style.display = 'block';
    resDetails.innerHTML = '<em>Simulating outage at primary facility (Hospital B) and executing automated failover routing...</em>';

    reqResultBox.style.display = 'block';
    reqTag.textContent = 'ROUTING FAILOVER';
    reqTag.className = 'status-badge-offline';
    reqDetails.innerHTML = '<em>Primary facility (Hospital B) unreachable. System is rerouting request to backup facility (Hospital C)...</em>';
    btnConfirm.style.display = 'none';

    try {
        const res = await fetch('/api/resilience/test', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                requester_id: 'HOSP-MUM-001',
                primary_node: 'HOSP-MUM-002',
                backup_node: 'HOSP-MUM-003',
                resource_type: 'ICU_BED',
                quantity: 1
            })
        });
        const data = await res.json();

        // 2. Synchronize UI with actual backend truth
        if (data.success && data.strategy === 'FAILOVER_SUCCESS') {
            const txId = data.transaction_id || 'TX-FAILOVER';
            const servicedByName = data.serviced_by_name || 'Hospital C (City Care Hospital)';
            const servicedById = data.serviced_by || 'HOSP-MUM-003';
            const failedPrimaryName = data.failed_primary_name || 'Hospital B (Super Specialty Hospital)';

            // Update Request Emergency Resource section accurately
            reqTag.textContent = 'RESERVED (FAILOVER)';
            reqTag.className = 'status-badge-online';
            reqDetails.innerHTML = `
                <div style="color: #34d399; font-weight: bold; margin-bottom: 6px;">✓ Resource Allocation Confirmed (via Failover)</div>
                <strong>Request ID:</strong> <code>${txId}</code><br>
                <strong>Allocated From:</strong> ${servicedByName} [${servicedById}]<br>
                <strong>Resource:</strong> ${data.quantity || 1}x ${data.resource_type || 'ICU_BED'}<br>
                <strong>Status:</strong> Reserved & Dispatched<br>
                <div style="font-size: 0.78rem; color: #fb923c; margin-top: 4px;">⚡ Rerouted automatically after primary (${failedPrimaryName}) outage</div>
            `;
            btnConfirm.style.display = 'none';

            // Update Network Resilience section
            resDetails.innerHTML = `
                <div style="margin-bottom: 8px; color: #34d399; font-weight: bold;">✓ Failover Successfully Resolved:</div>
                <div style="font-size: 0.85rem; margin-bottom: 8px; line-height: 1.6;">
                    <strong>Backup Facility:</strong> ${servicedByName} [${servicedById}]<br>
                    <strong>Request ID:</strong> <code>${txId}</code><br>
                    <strong>Allocated Resource:</strong> ${data.quantity}x ${data.resource_type}<br>
                    <strong>Status:</strong> Reserved & Dispatched
                </div>
                <div style="font-family: var(--font-mono); font-size: 0.75rem; color: #94a3b8; background: #050811; padding: 8px; border-radius: 6px; max-height: 160px; overflow-y: auto;">
                    ${(data.logs || []).map(l => `<div>• ${escapeHtml(l)}</div>`).join('')}
                </div>
            `;
        } else {
            // Backup exhausted or failed
            const failMsg = data.message || 'Failover attempted, but no suitable backup resource was available.';
            reqTag.textContent = 'FAILOVER EXHAUSTED';
            reqTag.className = 'status-badge-offline';
            reqDetails.innerHTML = `<span style="color: var(--accent-red); font-weight: bold;">${failMsg}</span>`;
            btnConfirm.style.display = 'none';

            resDetails.innerHTML = `
                <div style="color: var(--accent-red); font-weight: bold; margin-bottom: 6px;">✕ Failover Incomplete</div>
                <div>${failMsg}</div>
                <div style="font-family: var(--font-mono); font-size: 0.75rem; color: #94a3b8; background: #050811; padding: 8px; border-radius: 6px; margin-top: 8px;">
                    ${(data.logs || []).map(l => `<div>• ${escapeHtml(l)}</div>`).join('')}
                </div>
            `;
        }

        // Refresh all local facility inventory indicators
        loadMedicalNetwork();

    } catch (e) {
        reqTag.textContent = 'ERROR';
        reqTag.className = 'status-badge-offline';
        reqDetails.innerHTML = `<span style="color: var(--accent-red);">Resilience error: ${e.message}</span>`;
        resDetails.innerHTML = `<span style="color: var(--accent-red);">Resilience test error: ${e.message}</span>`;
    }
}

// =========================================================================
// 5. SECURE TELEMEDICINE CHANNEL (WEBRTC)
// =========================================================================

function openTelemedicineChannel() {
    addLogEntry('TELEMEDICINE', 'Opening secure telemedicine peer terminals for Hospital A and Hospital B...');
    window.open('/webrtc/hospital_a', 'Telemedicine_Hospital_A', 'width=560,height=620,left=100,top=100');
    setTimeout(() => {
        window.open('/webrtc/hospital_b', 'Telemedicine_Hospital_B', 'width=560,height=620,left=700,top=100');
    }, 400);
}

// =========================================================================
// 6. SYSTEM RESET
// =========================================================================

async function resetSystem() {
    if (!confirm('Synchronize and reset all medical facility inventories to default stock?')) return;
    try {
        await fetch('/api/system/reset', { method: 'POST' });
        clearLogs();
        addLogEntry('NETWORK', 'All regional medical inventories reset and synchronized successfully.');
        loadMedicalNetwork();
        lastSelectedSearchResult = null;
        const resBox = document.getElementById('search-result-box');
        if (resBox) resBox.style.display = 'none';
        const brBox = document.getElementById('broadcast-result-box');
        if (brBox) brBox.style.display = 'none';
        const p2pBox = document.getElementById('p2p-result-box');
        if (p2pBox) p2pBox.style.display = 'none';
        const resiBox = document.getElementById('resilience-result-box');
        if (resiBox) resiBox.style.display = 'none';
    } catch (e) {
        alert('Sync failed: ' + e.message);
    }
}
