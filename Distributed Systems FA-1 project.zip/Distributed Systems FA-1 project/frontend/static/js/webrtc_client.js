// WebRTC DataChannel Client for Distributed Multimedia Demonstration (Unit 1 & Unit 2)

class WebRTCPeer {
    constructor(peerId, remotePeerId, signalingPort = 8766) {
        this.peerId = peerId;
        this.remotePeerId = remotePeerId;
        this.signalingUrl = `ws://${window.location.hostname}:${signalingPort}`;
        this.pc = null;
        this.dataChannel = null;
        this.ws = null;
        
        this.config = {
            iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
        };
    }

    init() {
        this.log(`Connecting to WebRTC Signaling Server at ${this.signalingUrl}...`);
        this.ws = new WebSocket(this.signalingUrl);

        this.ws.onopen = () => {
            this.log('Signaling WebSocket connected. Registering peer identity: ' + this.peerId);
            this.ws.send(JSON.stringify({ type: 'join', peer_id: this.peerId }));
            this.updateSignalingStatus('CONNECTED', '#10b981');
        };

        this.ws.onmessage = async (event) => {
            const data = JSON.parse(event.data);
            await this.handleSignalingMessage(data);
        };

        this.ws.onerror = (err) => {
            this.log('Signaling error: ' + err);
            this.updateSignalingStatus('ERROR', '#ef4444');
        };

        this.setupPeerConnection();
    }

    setupPeerConnection() {
        this.pc = new RTCPeerConnection(this.config);

        // ICE Candidate handling
        this.pc.onicecandidate = (event) => {
            if (event.candidate) {
                this.log('Generated ICE Candidate, relaying via Signaling Server...');
                this.ws.send(JSON.stringify({
                    type: 'candidate',
                    target: this.remotePeerId,
                    candidate: event.candidate
                }));
            }
        };

        this.pc.onconnectionstatechange = () => {
            this.log(`PeerConnection State: ${this.pc.connectionState.toUpperCase()}`);
            if (this.pc.connectionState === 'connected') {
                this.updateConnectionStatus('PEER CONNECTED', '#10b981');
            }
        };

        // If this peer receives a DataChannel from remote offer
        this.pc.ondatachannel = (event) => {
            this.log('Received remote RTCDataChannel offer');
            this.dataChannel = event.channel;
            this.setupDataChannelEvents();
        };
    }

    setupDataChannelEvents() {
        if (!this.dataChannel) return;

        this.dataChannel.onopen = () => {
            this.log('>>> WebRTC DataChannel State: OPEN (Direct P2P Browser Channel Ready) <<<');
            this.updateChannelStatus('OPEN (P2P READY)', '#10b981');
            document.getElementById('btn-send').disabled = false;
        };

        this.dataChannel.onclose = () => {
            this.log('WebRTC DataChannel CLOSED');
            this.updateChannelStatus('CLOSED', '#ef4444');
            document.getElementById('btn-send').disabled = true;
        };

        this.dataChannel.onmessage = (event) => {
            this.log(`[RECEIVED FROM ${this.remotePeerId.toUpperCase()}]: ${event.data}`, 'msg-recv');
            this.appendChatMessage(this.remotePeerId.toUpperCase(), event.data, 'received');
        };
    }

    async connectToPeer() {
        this.log(`Initiating WebRTC DataChannel connection to ${this.remotePeerId}...`);
        
        // Create DataChannel (Initiator)
        this.dataChannel = this.pc.createDataChannel('emergency_telemedicine_stream');
        this.setupDataChannelEvents();

        // Create SDP Offer
        const offer = await this.pc.createOffer();
        await this.pc.setLocalDescription(offer);
        this.log('Created SDP Offer, sending to remote peer via Signaling Server...');

        this.ws.send(JSON.stringify({
            type: 'offer',
            target: this.remotePeerId,
            offer: offer
        }));
    }

    async handleSignalingMessage(data) {
        if (data.type === 'peer_joined' && data.peer_id === this.remotePeerId) {
            this.log(`Remote peer '${this.remotePeerId}' joined network.`);
            this.updateRemoteStatus('ONLINE', '#10b981');
        } else if (data.type === 'joined') {
            if (data.peers.includes(this.remotePeerId)) {
                this.updateRemoteStatus('ONLINE', '#10b981');
            }
        } else if (data.type === 'offer') {
            this.log('Received SDP Offer from ' + this.remotePeerId);
            await this.pc.setRemoteDescription(new RTCSessionDescription(data.offer));
            
            const answer = await this.pc.createAnswer();
            await this.pc.setLocalDescription(answer);
            this.log('Generated SDP Answer, returning via Signaling Server...');

            this.ws.send(JSON.stringify({
                type: 'answer',
                target: this.remotePeerId,
                answer: answer
            }));
        } else if (data.type === 'answer') {
            this.log('Received SDP Answer from ' + this.remotePeerId);
            await this.pc.setRemoteDescription(new RTCSessionDescription(data.answer));
        } else if (data.type === 'candidate') {
            this.log('Received remote ICE Candidate, adding to PeerConnection...');
            try {
                await this.pc.addIceCandidate(new RTCIceCandidate(data.candidate));
            } catch (e) {
                console.error(e);
            }
        }
    }

    sendMessage(text) {
        if (this.dataChannel && this.dataChannel.readyState === 'open') {
            this.dataChannel.send(text);
            this.log(`[SENT TO ${this.remotePeerId.toUpperCase()}]: ${text}`, 'msg-sent');
            this.appendChatMessage('YOU (' + this.peerId.toUpperCase() + ')', text, 'sent');
        } else {
            alert('DataChannel is not open yet! Click Connect first.');
        }
    }

    appendChatMessage(sender, text, type) {
        const chatBox = document.getElementById('chat-messages');
        if (!chatBox) return;
        const msgDiv = document.createElement('div');
        msgDiv.className = `chat-bubble ${type}`;
        msgDiv.innerHTML = `<strong>${sender}:</strong> ${text}`;
        chatBox.appendChild(msgDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    log(message, type = '') {
        const term = document.getElementById('webrtc-terminal');
        if (!term) return;
        const ts = new Date().toTimeString().split(' ')[0];
        const line = document.createElement('div');
        line.className = `log-line ${type}`;
        line.textContent = `[${ts}] ${message}`;
        term.appendChild(line);
        term.scrollTop = term.scrollHeight;
    }

    updateSignalingStatus(status, color) {
        const el = document.getElementById('signaling-status');
        if (el) {
            el.textContent = status;
            el.style.color = color;
        }
    }

    updateRemoteStatus(status, color) {
        const el = document.getElementById('remote-status');
        if (el) {
            el.textContent = status;
            el.style.color = color;
        }
    }

    updateConnectionStatus(status, color) {
        const el = document.getElementById('conn-status');
        if (el) {
            el.textContent = status;
            el.style.color = color;
        }
    }

    updateChannelStatus(status, color) {
        const el = document.getElementById('channel-status');
        if (el) {
            el.textContent = status;
            el.style.color = color;
        }
    }
}
